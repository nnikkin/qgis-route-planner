from qgis.PyQt.QtCore import QObject, pyqtSignal, Qt
from qgis.PyQt.QtWidgets import QListWidgetItem, QMessageBox

from qgis_route_planner.models.vehicle.vehicle_profile import VehicleProfile
from qgis_route_planner.repositories.db_connection import DbConnection
from qgis_route_planner.services.settings_service import SettingsService
from qgis_route_planner.views.settings_view import SettingsDialog


class SettingsController(QObject):
    """Контроллер диалога настроек плагина."""

    settings_saved = pyqtSignal(DbConnection)

    def __init__(self, settings_dialog: SettingsDialog, settings_service: SettingsService):
        super().__init__()

        self.__settings_dialog = settings_dialog
        self.__settings_service = settings_service
        self.__current_profile_id = None

        self.__connect_signals()
        self.__initialize()

    def __connect_signals(self):
        self.__settings_dialog.saveConButton.clicked.connect(self.__save_db_settings)
        self.__settings_dialog.saveNewProfileButton.clicked.connect(self.__save_profile)
        self.__settings_dialog.deleteProfileButton.clicked.connect(self.__delete_profile)
        self.__settings_dialog.editProfileButton.clicked.connect(self.__edit_profile)
        self.__settings_dialog.cancelProfileButton.clicked.connect(self.__cancel_edit)
        self.__settings_dialog.createProfileButton.clicked.connect(self.__create_new_profile)
        self.__settings_dialog.profilesListWidget.itemSelectionChanged.connect(self.__on_profile_selected)

    def set_current_tab_active(self, tab_index: int = 0):
        self.__settings_dialog.set_tab_active(tab_index)

    def set_tab_state(self, tab_index: int, state: bool):
        self.__settings_dialog.set_tab_state(tab_index, state)

    def __set_profile_mode(self, mode: str):
        """Переключает доступность формы профиля."""
        is_edit_mode = mode == "edit"
        has_selection = mode == "view"

        self.__enable_profile_form(is_edit_mode)
        self.__settings_dialog.saveNewProfileButton.setEnabled(is_edit_mode)
        self.__settings_dialog.cancelProfileButton.setEnabled(is_edit_mode)
        self.__settings_dialog.editProfileButton.setEnabled(has_selection)
        self.__settings_dialog.deleteProfileButton.setEnabled(has_selection)

    def __create_new_profile(self):
        """Создание нового профиля."""
        self.__current_profile_id = None
        self.__clear_profile_form()
        self.__settings_dialog.profilesListWidget.clearSelection()
        self.__set_profile_mode("edit")
        self.__settings_dialog.profileNameEdit.setFocus()

    def __edit_profile(self):
        """Редактирование выбранного профиля."""
        if self.__current_profile_id is None:
            return

        self.__set_profile_mode("edit")
        self.__settings_dialog.profileNameEdit.setFocus()

    def __save_profile(self):
        """Сохранение нового или изменённого профиля."""
        name = self.__settings_dialog.profileNameEdit.text().strip()
        if not name:
            QMessageBox.warning(
                parent=self.__settings_dialog,
                text="Введите название профиля!",
                buttons=QMessageBox.Ok,
            )
            return

        profile = VehicleProfile(
            name=name,
            plate=self.__settings_dialog.profilePlateEditEdit.text().strip(),
            height=self.__settings_dialog.profileHeightSpinBox.value(),
            width=self.__settings_dialog.profileWidthSpinBox.value(),
            weight=self.__settings_dialog.profileWeightSpinBox.value(),
            max_speed=self.__settings_dialog.profileSpeedSpinBox.value(),
        )

        try:
            if self.__current_profile_id is not None:
                self.__settings_service.update_profile(self.__current_profile_id, profile)
                message = "Профиль успешно обновлен!"
            else:
                self.__settings_service.create_profile(profile)
                message = "Профиль успешно создан!"

            self.__load_profiles()
            self.__cancel_edit()

            QMessageBox.information(
                parent=self.__settings_dialog,
                text=message,
                buttons=QMessageBox.Ok,
            )
        except Exception as e:
            QMessageBox.critical(
                parent=self.__settings_dialog,
                text=f"Ошибка сохранения профиля: {str(e)}",
                buttons=QMessageBox.Ok,
            )

    def __delete_profile(self):
        """Удаление выбранного профиля."""
        if self.__current_profile_id is None:
            return

        reply = QMessageBox.question(
            parent=self.__settings_dialog,
            text=f"Вы уверены, что хотите удалить профиль '{self.__settings_dialog.profileNameEdit.text()}'?",
            buttons=QMessageBox.Yes | QMessageBox.No,
        )

        if reply != QMessageBox.Yes:
            return

        try:
            self.__settings_service.delete_profile(self.__current_profile_id)
            self.__load_profiles()
            self.__cancel_edit()

            QMessageBox.information(
                parent=self.__settings_dialog,
                text="Профиль успешно удален!",
                buttons=QMessageBox.Ok,
            )
        except Exception as e:
            QMessageBox.critical(
                parent=self.__settings_dialog,
                text=f"Ошибка удаления профиля: {str(e)}",
                buttons=QMessageBox.Ok,
            )

    def __on_profile_selected(self):
        """Обработка выбора профиля из списка."""
        selected_items = self.__settings_dialog.profilesListWidget.selectedItems()
        if not selected_items:
            self.__cancel_edit()
            return

        profile_id = selected_items[0].data(Qt.UserRole)
        self.__current_profile_id = profile_id
        self.__load_profile_to_form(profile_id)
        self.__set_profile_mode("view")

    def __load_profile_to_form(self, profile_id: int):
        """Загружает данные профиля в форму."""
        try:
            profile_data = self.__settings_service.get_profile_by_id(profile_id)
            if not profile_data:
                self.__cancel_edit()
                return

            self.__settings_dialog.profileNameEdit.setText(profile_data.get("name", ""))
            self.__settings_dialog.profilePlateEditEdit.setText(profile_data.get("plate", ""))
            self.__settings_dialog.profileHeightSpinBox.setValue(float(profile_data.get("height", 0)))
            self.__settings_dialog.profileWidthSpinBox.setValue(float(profile_data.get("width", 0)))
            self.__settings_dialog.profileWeightSpinBox.setValue(float(profile_data.get("weight", 0)))
            self.__settings_dialog.profileSpeedSpinBox.setValue(float(profile_data.get("max_speed", 0)))
        except Exception as e:
            print(f"Error loading profile: {e}")

    def __load_profiles(self):
        """Загрузка списка профилей."""
        try:
            profiles = self.__settings_service.get_all_profiles()
            self.__settings_dialog.profilesListWidget.clear()

            for profile in profiles:
                item = QListWidgetItem(profile.get("name", "Без названия"))
                item.setData(Qt.UserRole, profile.get("id"))
                self.__settings_dialog.profilesListWidget.addItem(item)
        except Exception as e:
            print(f"Error loading profiles: {e}")

    def __clear_profile_form(self):
        """Очистка формы профиля."""
        self.__settings_dialog.profileNameEdit.clear()
        self.__settings_dialog.profilePlateEditEdit.clear()
        self.__settings_dialog.profileHeightSpinBox.setValue(0)
        self.__settings_dialog.profileWidthSpinBox.setValue(0)
        self.__settings_dialog.profileWeightSpinBox.setValue(0)
        self.__settings_dialog.profileSpeedSpinBox.setValue(0)

    def __enable_profile_form(self, enabled: bool):
        """Включение или отключение полей формы профиля."""
        self.__settings_dialog.profileNameEdit.setEnabled(enabled)
        self.__settings_dialog.profilePlateEditEdit.setEnabled(enabled)
        self.__settings_dialog.profileHeightSpinBox.setEnabled(enabled)
        self.__settings_dialog.profileWidthSpinBox.setEnabled(enabled)
        self.__settings_dialog.profileWeightSpinBox.setEnabled(enabled)
        self.__settings_dialog.profileSpeedSpinBox.setEnabled(enabled)

    def __cancel_edit(self):
        """Отмена редактирования или создания профиля."""
        self.__current_profile_id = None
        self.__clear_profile_form()
        self.__set_profile_mode("empty")
        self.__settings_dialog.profilesListWidget.clearSelection()

    def __initialize(self):
        self.__set_db_form()
        self.__cancel_edit()

    def __set_db_form(self):
        try:
            s = self.__settings_service.load_db_params()
            if not s:
                self.__settings_service.set_vehicle_repository(None)
                return

            self.__settings_dialog.hostnameEdit.setText(s.host)
            self.__settings_dialog.portEdit.setText(str(s.port))
            self.__settings_dialog.usernameEdit.setText(s.username)
            self.__settings_dialog.passwordEdit.setText(s.password)
            self.__settings_dialog.dbNameEdit.setText(s.database)

            if s.is_complete():
                self.__settings_service.set_vehicle_repository(s)
                self.__load_profiles()
            else:
                self.__settings_service.set_vehicle_repository(None)

            if hasattr(self.__settings_dialog, "schemaComboBox"):
                pass

        except Exception as e:
            print(e)

    def __save_db_settings(self):
        host = self.__settings_dialog.hostnameEdit.text()
        port = self.__settings_dialog.portEdit.text()
        username = self.__settings_dialog.usernameEdit.text()
        password = self.__settings_dialog.passwordEdit.text()
        database = self.__settings_dialog.dbNameEdit.text()

        try:
            db_connection = DbConnection(
                host=host,
                port=int(port),
                database=database,
                username=username,
                password=password,
            )

            if db_connection.test_connection():
                self.__settings_service.save_db_params(db_connection)
                self.__settings_service.set_vehicle_repository(db_connection)
                self.__load_profiles()
                self.__cancel_edit()

                self.settings_saved.emit(db_connection)
                QMessageBox.information(
                    parent=self.__settings_dialog,
                    text="Настройки успешно сохранены!",
                    buttons=QMessageBox.Ok,
                )
            else:
                QMessageBox.warning(
                    parent=self.__settings_dialog,
                    text="Не удалось подключиться к базе данных.",
                    buttons=QMessageBox.Ok,
                )
        except Exception as e:
            print(e)
            QMessageBox.critical(
                parent=self.__settings_dialog,
                text=f"Ошибка сохранения: {str(e)}",
                buttons=QMessageBox.Ok,
            )
