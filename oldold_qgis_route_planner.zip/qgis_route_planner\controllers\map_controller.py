from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QAction, QCursor
from qgis.PyQt.QtWidgets import QDialog, QListWidgetItem, QMenu, QMessageBox
from qgis.core import QgsGeometry, QgsPointXY, QgsWkbTypes
from qgis.gui import QgsMapToolPan, QgsMapToolZoom, QgsRubberBand, QgsVertexMarker

from qgis_route_planner.models.route.point_type import PointType
from qgis_route_planner.models.route.route_point_collection import RoutePointCollection
from qgis_route_planner.services.map_service import MapService
from qgis_route_planner.services.restriction_service import RestrictionService
from qgis_route_planner.services.routing_service import RoutingService
from qgis_route_planner.views.main_view import PluginMainWindow
from qgis_route_planner.views.point_restriction_view import PointRestrictionDialog
from qgis_route_planner.views.widgets.select_point_map_tool import SelectPointMapTool


class MapController:
    """Тонкий контроллер карты: только UI-события и связывание сервисов."""

    def __init__(
            self,
            view: PluginMainWindow,
            map_service: MapService,
            routing_service: RoutingService,
            restriction_service: RestrictionService | None,
    ):
        self.__view = view
        self.__map_service = map_service
        self.__routing_service = routing_service
        self.__restriction_service = restriction_service
        self.__points = RoutePointCollection()
        self.__point_markers: dict[int, QgsVertexMarker] = {}
        self.__current_route = None
        self.__route_band = None
        self.__context_menu_point = None
        self.__temp_node_id = None

        self.__point_zoom_in = QgsMapToolZoom(self.__view.mapView, False)
        self.__point_zoom_out = QgsMapToolZoom(self.__view.mapView, True)
        self.__point_pan = QgsMapToolPan(self.__view.mapView)
        self.__point_select_tool = SelectPointMapTool(self.__view.mapView)

        self.__connect_signals()

    def __connect_signals(self):
        self.__view.mapView.zoom_in_btn.clicked.connect(self.__zoom_in)
        self.__view.mapView.zoom_out_btn.clicked.connect(self.__zoom_out)
        self.__view.mapView.pan_btn.clicked.connect(self.__pan)
        self.__view.mapView.select_btn.clicked.connect(self.activate_selection)
        self.__point_select_tool.pointClicked.connect(self.on_map_point_selected)
        self.__view.clear_list_button.clicked.connect(self.clear_all_points)

    def activate_selection(self):
        self.__view.mapView.setMapTool(self.__point_select_tool)

    def initialize_map(self, schema: str = "routing"):
        try:
            layers = self.__map_service.load_all_spatial_layers(schema=schema)
            if not layers:
                print(f"No layers loaded from schema '{schema}'")
                return

            self.__view.mapView.set_layers(layers)
            print("Слои загружены.")
        except Exception as e:
            print(f"Failed to initialize map: {e}")

    def on_map_point_selected(self, point: QgsPointXY):
        if not self.__routing_service.is_point_on_road_network(point):
            QMessageBox.warning(
                self.__view,
                "Ошибка",
                "Точка должна находиться на дорожной сети!\nПожалуйста, выберите точку на дороге.",
            )
            return

        snapped = self.__routing_service.snap_point_to_road(point)
        if snapped:
            point, node_id = snapped
            self.__temp_node_id = node_id
        else:
            self.__temp_node_id = None

        self.show_context_menu_for_point(point)

    def show_context_menu_for_point(self, point: QgsPointXY):
        menu = QMenu(self.__view.mapView)
        current_point = point
        current_node_id = self.__temp_node_id
        has_start = any(p.point_type == PointType.START for p in self.__points.points)
        has_end = any(p.point_type == PointType.END for p in self.__points.points)

        start_available = not has_start
        end_available = has_start and not has_end
        waypoint_available = has_start

        actions = [
            ("Установить как начальную точку", PointType.START, start_available),
            ("Установить как конечную точку", PointType.END, end_available),
            ("Установить как промежуточную точку", PointType.WAYPOINT, waypoint_available),
        ]

        for title, point_type, is_enabled in actions:
            action = QAction(title, menu)
            action.triggered.connect(
                lambda checked=False, pt=point_type, cp=current_point: self.__add_route_point(cp, pt, current_node_id)
            )
            action.setEnabled(is_enabled)
            menu.addAction(action)

        restriction_action = QAction("Создать ограничение точки", menu)
        restriction_action.triggered.connect(
            lambda checked=False, cp=current_point, cn=current_node_id: self.__create_point_restriction(cp, cn)
        )
        menu.addAction(restriction_action)

        menu.exec_(QCursor.pos())

    def __create_point_restriction(self, point: QgsPointXY, node_id: int | None):
        if node_id is None:
            node_id = self.__routing_service.find_nearest_node(point)

        if node_id is None:
            QMessageBox.warning(
                self.__view,
                "Ошибка",
                "Не удалось определить node_id для точки.\nПожалуйста, выберите точку ближе к дороге.",
            )
            return

        restriction_types = self.__restriction_service.get_restriction_types()
        if not restriction_types:
            QMessageBox.warning(
                self.__view,
                "Ошибка",
                "Список типов ограничений недоступен. Проверьте подключение к базе данных.",
            )
            return

        dialog = PointRestrictionDialog(node_id=node_id, restriction_types=restriction_types, parent=self.__view)
        if dialog.exec_() != QDialog.Accepted:
            return

        try:
            self.__restriction_service.create_restriction(dialog.get_restriction())
            QMessageBox.information(
                self.__view,
                "Готово",
                "Ограничение для точки создано.",
            )
        except Exception as e:
            QMessageBox.critical(
                self.__view,
                "Ошибка",
                f"Не удалось сохранить ограничение: {str(e)}",
            )

    def __add_route_point(self, point: QgsPointXY, point_type: PointType, node_id: int | None):
        if node_id is None:
            node_id = self.__routing_service.find_nearest_node(point)

        if node_id is None:
            QMessageBox.warning(
                self.__view,
                "Ошибка",
                "Не удалось найти ближайший узел дорожной сети.\nПожалуйста, выберите точку ближе к дороге.",
            )
            return

        route_point = self.__points.add_point(point, point_type, node_id)
        self._add_point_marker(route_point)
        self._update_points_list()

        self.__try_build_route()

    def _add_point_marker(self, point):
        marker = QgsVertexMarker(self.__view.mapView)
        marker.setCenter(point.point)
        marker.setIconType(QgsVertexMarker.IconType.ICON_CROSS)
        marker.setIconSize(10)
        marker.setPenWidth(3 if point.point_type in {PointType.START, PointType.END} else 2)
        self._update_marker_color(point, marker)
        marker.show()
        self.__point_markers[point.id] = marker

    def _update_marker_color(self, point, marker=None):
        marker = marker or self.__point_markers.get(point.id)
        if not marker:
            return

        if point.point_type == PointType.START:
            marker.setColor(Qt.green)
        elif point.point_type == PointType.END:
            marker.setColor(Qt.red)
        else:
            marker.setColor(Qt.blue)

    def _update_points_list(self):
        self.__view.points_list_widget.clear()

        for point in self.__points.points:
            if point.point_type == PointType.START:
                prefix = "НАЧАЛО"
            elif point.point_type == PointType.END:
                prefix = "КОНЕЦ"
            else:
                prefix = f"Точка {point.order}"

            item = QListWidgetItem(f"{prefix}: ({point.point.x():.6f}, {point.point.y():.6f})")
            item.setData(Qt.UserRole, point.id)
            self.__view.points_list_widget.addItem(item)

        self.__view.clear_list_button.setEnabled(bool(self.__points.points))

    def _update_marker_for_point(self, point_id: int):
        point = self.__points.get_point(point_id)
        if point:
            self._update_marker_color(point)

    def _display_route(self, route: list):
        self._clear_route()
        if not route:
            return

        route_band = QgsRubberBand(self.__view.mapView, QgsWkbTypes.LineGeometry)
        route_band.setColor(Qt.blue)
        route_band.setWidth(3)

        all_points = []
        for edge in route:
            geom = QgsGeometry.fromWkt(edge["geom"])
            all_points.extend(geom.asPolyline())

        if not all_points:
            return

        route_geom = QgsGeometry.fromPolylineXY(all_points)
        route_band.setToGeometry(route_geom, None)
        self.__route_band = route_band
        self.__current_route = route

        self.__view.mapView.setExtent(route_geom.boundingBox())
        self.__view.mapView.refresh()

    def _show_route_info(self, route):
        info = self.__routing_service.get_route_info(route)
        self.__view.display_route_info(route, info)

    def _clear_route(self):
        if self.__route_band:
            self.__view.mapView.scene().removeItem(self.__route_band)
            self.__route_band = None
        self.__current_route = None
        self.__view.clear_route_display()

    def __try_build_route(self):
        if not self.__points.has_required_points():
            self._clear_route()
            return

        start_point = next((p for p in self.__points.points if p.point_type == PointType.START), None)
        end_point = next((p for p in self.__points.points if p.point_type == PointType.END), None)
        if not start_point or not end_point or start_point.node_id is None or end_point.node_id is None:
            self._clear_route()
            return

        route = self.__routing_service.calculate_route(start_point.node_id, end_point.node_id)
        if route:
            self._display_route(route)
            self._show_route_info(route)
        else:
            QMessageBox.warning(
                self.__view,
                "Ошибка",
                "Не удалось построить маршрут между выбранными точками",
            )

    def remove_point(self, point_id: int):
        point = self.__points.remove_point(point_id)
        if not point:
            return

        marker = self.__point_markers.pop(point_id, None)
        if marker:
            self.__view.mapView.scene().removeItem(marker)

        self._update_points_list()
        self.__try_build_route()

    def clear_all_points(self):
        for marker in self.__point_markers.values():
            self.__view.mapView.scene().removeItem(marker)
        self.__point_markers.clear()
        self.__points.clear()
        self._clear_route()
        self._update_points_list()

    def change_point_type(self, point_id: int, new_type: PointType):
        point = self.__points.change_point_type(point_id, new_type)
        if not point:
            return

        self._update_marker_for_point(point_id)
        self._update_points_list()
        self.__try_build_route()

    def __zoom_in(self):
        self.__view.mapView.setMapTool(self.__point_zoom_in)

    def __zoom_out(self):
        self.__view.mapView.setMapTool(self.__point_zoom_out)

    def __pan(self):
        self.__view.mapView.setMapTool(self.__point_pan)
