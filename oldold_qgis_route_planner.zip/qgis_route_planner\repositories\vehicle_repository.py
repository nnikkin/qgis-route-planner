from qgis_route_planner.repositories.db_connection import DbConnection
from qgis_route_planner.models.vehicle.vehicle_profile import VehicleProfile


class VehicleProfileRepository:
    def __init__(self, db: DbConnection):
        self._db = db

    def create_tables(self):
        self._db.execute_nquery("""
        CREATE TABLE IF NOT EXISTS routing.vehicle_profiles (
        id INTEGER PRIMARY KEY,
        name VARCHAR(50),
        plate VARCHAR(20),
        height FLOAT,
        width FLOAT,
        weight FLOAT,
        max_speed FLOAT);
        """)
        self._db.execute_nquery(
            "ALTER TABLE routing.vehicle_profiles ADD COLUMN IF NOT EXISTS plate VARCHAR(20)"
        )

    def get_all(self) -> list[dict]:
        return self._db.execute_query(
            "SELECT id, name, plate, height, width, weight, max_speed "
            "FROM routing.vehicle_profiles"
        )

    def get_by_id(self, profile_id: int) -> dict | None:
        rows = self._db.execute_query(
            "SELECT id, name, plate, height, width, weight, max_speed "
            "FROM routing.vehicle_profiles WHERE id = %s",
            [profile_id]
        )
        return rows[0] if rows else None

    def add_profile(self, profile: VehicleProfile):
        next_id = self._get_next_id()
        self._db.execute_nquery(
            "INSERT INTO routing.vehicle_profiles (id, name, plate, height, width, weight, max_speed) "
            "VALUES (%s, %s, %s, %s, %s, %s, %s)",
            [next_id, profile.name, profile.plate, profile.height, profile.width, profile.weight, profile.max_speed]
        )

    def del_profile(self, profile_id: int):
        self._db.execute_nquery(
            "DELETE FROM routing.vehicle_profiles WHERE id = %s", [profile_id]
        )

    def upd_profile(self, profile_id: int, profile: VehicleProfile):
        self._db.execute_nquery(
            "UPDATE routing.vehicle_profiles SET name = %s, plate = %s, "
            "height = %s, width = %s, weight = %s, max_speed = %s "
            "WHERE id = %s",
            [profile.name, profile.plate, profile.height, profile.width,
             profile.weight, profile.max_speed, profile_id]
        )

    def _get_next_id(self) -> int:
        rows = self._db.execute_query("SELECT COALESCE(MAX(id), 0) + 1 AS next_id FROM routing.vehicle_profiles")
        return int(rows[0]["next_id"]) if rows else 1
