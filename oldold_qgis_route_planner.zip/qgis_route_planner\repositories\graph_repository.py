import psycopg
from qgis_route_planner.repositories.db_connection import DbConnection
from qgis_route_planner.repositories.layer_repository import LayerRepository

from qgis.core import QgsTask

class RoadGraphRepository:
    def __init__(self, db: DbConnection, layer_repository: LayerRepository):
        self.__db = db
        self.__layer_repository = layer_repository
        pass

    def create_topology(self) -> bool:
        """
            Creates a routing graph
        """

        count = self.__db.execute_query("SELECT COUNT(*) FROM routing.graph_edges;")

        if count and count[0][0] == 0:
            print("Нет данных в таблице graph_edges. Сначала загрузите данные!")
            return False

        # Заполнение source и target
        self.__db.execute_nquery("""
            UPDATE routing.graph_edges AS e
            SET source = v.node_id
            FROM routing.graph_nodes AS v
            WHERE ST_DWithin(ST_StartPoint(e.geom), v.geom, 0.000001);
         """)

        self.__db.execute_nquery("""
            UPDATE routing.graph_edges AS e
            SET target = v.node_id
            FROM routing.graph_nodes AS v
            WHERE ST_DWithin(ST_EndPoint(e.geom), v.geom, 0.000001);
        """)

        # Заполнение cost как длину в метрах
        self.__db.execute_nquery("""
            UPDATE routing.graph_edges
            SET
                cost = ST_Length(geom::geography),
                reverse_cost = ST_Length(geom::geography);
        """)

        # Для односторонних дорог устанавливаем reverse_cost = -1
        self.__db.execute_nquery("""
                UPDATE routing.graph_edges
                SET reverse_cost = -1
                WHERE is_oneway = TRUE;
            """)

        return True

    def create_tables(self) -> bool:
        """
            Creates necessary tables
        """
        try:
            for cmd in [
                'CREATE SCHEMA IF NOT EXISTS routing;',
                'CREATE EXTENSION IF NOT EXISTS postgis;',
                'CREATE EXTENSION IF NOT EXISTS pgrouting;',
                'CREATE EXTENSION IF NOT EXISTS hstore;'
            ]:
                self.__db.execute_nquery(cmd)

            self.__db.execute_nquery("""
                CREATE TABLE IF NOT EXISTS routing.graph_nodes (
                    node_id BIGINT PRIMARY KEY,
                    in_edges BIGINT[],
                    out_edges BIGINT[],
                    x DOUBLE PRECISION,
                    y DOUBLE PRECISION,
                    geom GEOMETRY(Point, 4326)
                );
            """)

            self.__db.execute_nquery("""
                CREATE TABLE IF NOT EXISTS routing.road_classes (
                    class_id SMALLINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
                    class_name VARCHAR(20) UNIQUE NOT NULL
                );
            """)

            self.__db.execute_nquery("""
                CREATE TABLE IF NOT EXISTS routing.graph_edges (
                    edge_id BIGINT PRIMARY KEY,
                    source BIGINT REFERENCES routing.graph_nodes(node_id),
                    target BIGINT REFERENCES routing.graph_nodes(node_id),
                    geom GEOMETRY(LineString, 4326),
                    cost DOUBLE PRECISION,
                    reverse_cost DOUBLE PRECISION,
                    road_class_id SMALLINT REFERENCES routing.road_classes(class_id),
                    name TEXT,
                    is_oneway BOOLEAN,
                    max_speed_kmh DOUBLE PRECISION
                );
            """)

            # Надо заполнить таблицу road_classes уникальными значениями класса дорог, которые есть в lines
            self.__db.execute_nquery("""
                WITH inserted_classes AS (
                    INSERT INTO routing.road_classes (class_name)
                    SELECT DISTINCT highway 
                    FROM public.lines 
                    WHERE highway IS NOT NULL
                    ON CONFLICT (class_name) DO NOTHING
                    RETURNING class_id, class_name
                ),
                all_classes AS (
                    SELECT class_id, class_name FROM inserted_classes
                    UNION ALL
                    SELECT class_id, class_name FROM routing.road_classes
                )
                
                INSERT INTO routing.graph_edges (
                    edge_id, geom, road_class_id, name, is_oneway, max_speed_kmh
                )
                SELECT 
                    l.osm_id::bigint,
                    ST_Transform(l.geom, 4326),
                    ac.class_id, -- Используем ID из справочника
                    l.name,
                    CASE
                        WHEN (l.other_tags::hstore)->'oneway' IN ('yes', '1', 'true') THEN TRUE 
                        ELSE FALSE 
                    END,
                    COALESCE(
                        NULLIF(regexp_replace((l.other_tags::hstore)->'maxspeed', '[^0-9]', '', 'g'), '')::double precision, 
                        60
                    )
                FROM public.lines l
                JOIN all_classes ac ON l.highway = ac.class_name
                ON CONFLICT (edge_id) DO NOTHING;
            """)

            count = self.__db.execute_query("SELECT COUNT(*) FROM routing.graph_nodes;")[0][0]
            if count == 0:
                self.__db.execute_nquery("""
                    INSERT INTO routing.graph_nodes (node_id, in_edges, out_edges, x, y, geom)
                    SELECT id, in_edges, out_edges, x, y, geom
                    FROM pgr_extractVertices(
                        'SELECT edge_id as id, geom FROM routing.graph_edges ORDER BY edge_id'
                    )
                    ON CONFLICT (node_id) DO NOTHING;
                """)

            # Создаём индексы для производительности
            self.__db.execute_nquery("""
                CREATE INDEX IF NOT EXISTS idx_graph_edges_geom 
                ON routing.graph_edges USING GIST (geom);
            """)

            self.__db.execute_nquery("""
                CREATE INDEX IF NOT EXISTS idx_graph_nodes_geom 
                ON routing.graph_nodes USING GIST (geom);
            """)

            self.create_topology()

            print("Инициализация завершена успешно")
            return True

        except Exception as e:
            print(f"КРИТИЧЕСКАЯ ОШИБКА В ПОТОКЕ: {e}")
            return False

    def get_route(self, start_id: int, end_id: int, waypoints_ids: list[int] = None) -> list[dict]:
        print(f"Поиск маршрута от {start_id} до {end_id}")
        waypoints_ids = waypoints_ids or []

        # Проверяем существование узлов
        start_check = self.__db.execute_query(
            "SELECT node_id FROM routing.graph_nodes WHERE node_id = %s",
            [start_id]
        )
        end_check = self.__db.execute_query(
            "SELECT node_id FROM routing.graph_nodes WHERE node_id = %s",
            [end_id]
        )

        for waypoint_id in waypoints_ids:
            waypoint_check = self.__db.execute_query(
                "SELECT node_id FROM routing.graph_nodes WHERE node_id = %s",
                [waypoint_id]
            )
            if not waypoint_check:
                print(f"Промежуточный узел {waypoint_id} не найден в БД!")
                return []

        if not start_check:
            print(f"Стартовый узел {start_id} не найден в БД!")
            return []

        if not end_check:
            print(f"Конечный узел {end_id} не найден в БД!")
            return []

        if len(waypoints_ids) == 0:
            rows = self.__db.execute_query("""
                SELECT e.edge_id, ST_AsText(e.geom) AS geom,
                       r.cost, r.agg_cost
                FROM pgr_dijkstra(
                    'SELECT edge_id as id, source, target, cost, reverse_cost
                     FROM routing.graph_edges',
                    %s, %s
                ) AS r
                JOIN routing.graph_edges AS e ON r.edge = e.edge_id
                ORDER BY r.seq
            """, [start_id, end_id])
            res = [
                {
                    "edge_id": row[0],
                    "geom": row[1],
                    "cost": row[2],
                    "agg_cost": row[3],
                }
                for row in rows
            ]

        else:
            rows = self.__db.execute_query("""
                WITH point_pairs AS (
                    SELECT 
                        id AS start_node, 
                        LEAD(id) OVER (ORDER BY ord) AS end_node
                    FROM UNNEST(%s) WITH ORDINALITY AS t(id, ord)
                )
                SELECT e.edge_id, ST_AsText(e.geom) AS geom,
                       r.cost, r.agg_cost, r.seq
                FROM pgr_dijkstra(
                    'SELECT edge_id as id, source, target, cost, reverse_cost FROM routing.graph_edges',
                    (SELECT array_agg(start_node) FROM point_pairs WHERE end_node IS NOT NULL),
                    (SELECT array_agg(end_node) FROM point_pairs WHERE end_node IS NOT NULL),
                    directed := true
                ) AS r
                JOIN routing.graph_edges AS e ON r.edge = e.edge_id
                ORDER BY r.path_id, r.seq;
            """, [start_id] + waypoints_ids[:] + [end_id])
            res = [
                {
                    "edge_id": row[0],
                    "geom": row[1],
                    "cost": row[2],
                    "agg_cost": row[3],
                    "seq": row[4] if len(row) > 4 else None,
                }
                for row in rows
            ]

        return res


    def find_nearest_node(self, x: float, y: float, max_distance_m: float = 50.0):
        """
        Находит ближайший узел графа к заданной точке
        Возвращает (node_id, distance) или None
        """
        result = self.__db.execute_query("""
            SELECT node_id, 
                   ST_Distance(
                       geom::geography, 
                       ST_SetSRID(ST_MakePoint(%s, %s), 4326)::geography
                   ) as distance
            FROM routing.graph_nodes
            WHERE ST_DWithin(
                geom::geography, 
                ST_SetSRID(ST_MakePoint(%s, %s), 4326)::geography, 
                %s
            )
            ORDER BY distance
            LIMIT 1
        """, [x, y, x, y, max_distance_m])

        return result[0] if result else None

    def is_point_on_road_network(self, x: float, y: float, max_distance_m: float = 50.0) -> bool:
        """Проверяет, находится ли точка на дорожной сети"""
        return self.find_nearest_node(x, y, max_distance_m) is not None

    def get_node_coordinates(self, node_id: int) -> tuple[float, float] | None:
        """Возвращает координаты узла (x, y) по его ID."""
        query = """
            SELECT x, y 
            FROM routing.graph_nodes 
            WHERE node_id = %s
        """
        result = self.__db.execute_query(query, [node_id])

        if result and len(result) > 0:
            # result[0] — это первая строка, result[0][0] — это x, result[0][1] — это y
            return float(result[0][0]), float(result[0][1])

        return None
