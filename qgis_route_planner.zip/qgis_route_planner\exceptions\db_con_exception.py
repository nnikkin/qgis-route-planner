class DatabaseConnectionException(Exception):
    pass