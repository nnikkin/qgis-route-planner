import os
from qgis_route_planner import resources

from qgis.PyQt.QtCore import QCoreApplication, QSettings, QTranslator
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMessageBox

from .controllers import (
    InitDialogsController,
    MainWindowController,
    RestrictionWindowController,
    SettingsWindowController,
)
from .data.models import DbConfigModel, LayerConfigModel, ColumnsConfigModel

from .repositories import (
    RoadGraphRepository,
    LayerRepository,
    RestrictionRepository,
    VehicleProfileRepository,
    DbConnection,
)

from .services import (
    SpatialDataService,
    RestrictionService,
    RoutingService,
    SettingsService,
)

from .views import PluginMainWindow, ConnectionConfigDialog, SettingsDialog, LayersSelectDialog, LayerColumnsDialog

from .utils import GeometryType


class QgisRoutePlanner:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.actions = []
        self.menu = self.tr(u"&Поиск маршрутов")
        self.first_start = True

        self.__db_connection: DbConnection = None

        self.__settings_service: SettingsService = None
        self.__spatial_data_service: SpatialDataService = None
        self.__routing_service: RoutingService = None
        self.__restriction_service: RestrictionService = None

        self.__vehicle_repo: VehicleProfileRepository = None
        self.__layer_repo: LayerRepository = None
        self.__graph_repo: RoadGraphRepository = None
        self.__restriction_repo: RestrictionRepository = None

        self.__main_controller: MainWindowController = None
        self.__init_dialogs_controller: InitDialogsController = None
        self.__settings_controller: SettingsWindowController = None
        self.__restriction_controller: RestrictionWindowController = None

        self.__db_config_model: DbConfigModel = None
        self.__layers_config_model: LayerConfigModel = None
        self.__cols_config_model: ColumnsConfigModel = None

        self.__main_window: PluginMainWindow = None
        self.__restriction_dialog = None
        self.__settings_dialog: SettingsDialog = None
        self.__db_config_dialog: ConnectionConfigDialog = None
        self.__layer_select_dialog: LayersSelectDialog = None
        self.__cols_config_dialog: LayerColumnsDialog = None

        from qgis.PyQt.QtCore import QLibraryInfo
        locale = QSettings().value("locale/userLocale", "ru")
        locale_path = os.path.join(self.plugin_dir, "i18n", f"QgisRoutePlanner_{locale}.qm")
        self.__install_translator(locale_path)

        qt_translations_path = QLibraryInfo.location(QLibraryInfo.TranslationsPath)
        qt_locale_path = os.path.join(qt_translations_path, f"qtbase_{locale.split('_')[0]}.qm")
        self.__install_translator(qt_locale_path)

    def __install_translator(self, locale_path: str):
        try:
            if os.path.exists(locale_path):
                self.__plugin_translator = QTranslator()
                self.__plugin_translator.load(locale_path)
                QCoreApplication.installTranslator(self.__plugin_translator)
        except Exception as e:
            print(e)

    def tr(self, message):
        return QCoreApplication.translate("QgisRoutePlanner", message)

    def add_action(
            self,
            icon_path,
            text,
            callback,
            enabled_flag=True,
            add_to_menu=True,
            add_to_toolbar=True,
            status_tip=None,
            whats_this=None,
            parent=None,
    ):
        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)
        if whats_this is not None:
            action.setWhatsThis(whats_this)
        if add_to_toolbar:
            self.iface.addToolBarIcon(action)
        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action)

        self.actions.append(action)
        return action

    def initGui(self):
        icon_path = f":/plugins/qgis_route_planner/plugin_icon"
        self.add_action(
            icon_path,
            text=self.tr(u"Открыть модуль поиска маршрутов"),
            callback=self.run,
            parent=self.iface.mainWindow(),
        )
        self.first_start = True

    def unload(self):
        for action in self.actions:
            self.iface.removePluginMenu(self.tr(u"&Поиск маршрутов"), action)
            self.iface.removeToolBarIcon(action)

        if self.__main_controller is not None:
            self.__main_controller.clear_everything()

    def __init_views(self):
        self.__main_window = PluginMainWindow()
        self.__settings_dialog = SettingsDialog()
        #self.__restriction_dialog =

    def __init_controllers(self):
        self.__settings_controller = SettingsWindowController(
            self.__db_config_model,
            self.__settings_service,
            self.__settings_dialog,
        )
        self.__settings_controller.reconnect_requested.connect(self.__reconnect_requested)
        self.__settings_controller.graph_rebuild_requested.connect(self.__on_graph_rebuild_requested)

        self.__main_controller = MainWindowController(
            self.__settings_controller,
            self.__spatial_data_service,
            self.__routing_service,
            self.__main_window,
        )
        # self.__restriction_controller = RestrictionController(self.__settings_dialog, self.__restriction_service)

    def __init_repositories(self):
        self.__vehicle_repo = VehicleProfileRepository(self.__db_connection)
        self.__layer_repo = LayerRepository(self.__db_connection)
        self.__graph_repo = RoadGraphRepository(self.__db_connection, self.__layer_repo)
        #self.__restriction_repo = RestrictionRepository(self.__db_connection)

    def __init_services(self):
        self.__settings_service = SettingsService(self.__vehicle_repo)
        self.__spatial_data_service = SpatialDataService(self.__layer_repo, self.__graph_repo, self.__vehicle_repo)
        self.__routing_service = RoutingService(self.__graph_repo)
        #self.__restriction_service = RestrictionService(self.__restriction_repo)


    def __db_con_test(self):
        self.__db_connection = DbConnection(
            host=self.__db_config_model.host,
            port=self.__db_config_model.port,
            username=self.__db_config_model.username,
            password=self.__db_config_model.password,
            database=self.__db_config_model.database,
            schema=self.__db_config_model.schema,
        )

        if self.__db_connection.test_connection():
            self.__init_repositories()
            self.__init_services()
            self.__init_dialogs_controller.set_service(self.__spatial_data_service)

    def __db_con_created(self):
        self.__db_connection = DbConnection(
            host=self.__db_config_model.host,
            port=self.__db_config_model.port,
            username=self.__db_config_model.username,
            password=self.__db_config_model.password,
            database=self.__db_config_model.database,
            schema=self.__db_config_model.schema,
        )

        if self.__main_controller and self.__settings_controller:
            self.__main_controller.close_main_window()
            self.__settings_controller.close_settings_window()

        self.__init_views()
        self.__init_repositories()
        self.__init_services()
        self.__init_controllers()

        self.__settings_service.save_db_params(self.__db_connection)

        self.__layer_select_dialog.open()

    def __layers_selected(self):
        self.__selected_layers = self.__layers_config_model.selected_layers
        self.__cols_config_dialog.open()

    def __columns_configured(self):
        self.__column_mapping = self.__cols_config_model.mappings
        self.__initialization_finished()

    def __initialization_finished(self ):
        self.first_start = False

        self.__spatial_data_service.run_init_database(self.__selected_layers, self.__column_mapping)

        self.__main_controller.open_main_window()
        self.__main_controller.initialize_map()

    def __initialization_cancelled(self):
        if self.__main_controller:
            self.__main_controller.close_main_window()

        self.first_start = True
        self.__init_dialogs_controller = None

    def __on_graph_rebuild_requested(self):
        try:
            self.__main_controller.close_main_window()
            self.__graph_repo.create_topology()
            self.__main_controller.open_main_window()
            self.__main_controller.initialize_map()
            self.__settings_controller.close_settings_window()
        except Exception as e:
            QMessageBox.critical(None, "Ошибка", f"Не удалось перестроить граф:\n{e}", QMessageBox.Ok)

    def __reconnect_requested(self):
        self.__init_dialogs_controller.con_test_requested.connect(
            self.__db_con_test
        )
        self.__init_dialogs_controller.con_params_obtained.connect(
            self.__db_con_created
        )
        self.__init_dialogs_controller.columns_configured.connect(
            self.__columns_configured
        )
        self.__init_dialogs_controller.init_cancelled.connect(
            self.__reconnect_cancelled
        )

    def __reconnect_cancelled(self):
        pass


    def run(self):
        if self.first_start:
            self.__db_config_model = DbConfigModel()
            self.__layers_config_model = LayerConfigModel()
            self.__cols_config_model = ColumnsConfigModel()

            self.__init_dialogs_controller = InitDialogsController(
                db_config_model=self.__db_config_model,
                layer_config_model=self.__layers_config_model,
                columns_config_model=self.__cols_config_model
            )
            self.__init_dialogs_controller.con_test_requested.connect(
                self.__db_con_test
            )
            self.__init_dialogs_controller.con_params_obtained.connect(
                self.__db_con_created
            )
            self.__init_dialogs_controller.layers_selected.connect(
                self.__layers_selected
            )
            self.__init_dialogs_controller.columns_configured.connect(
                self.__columns_configured
            )
            self.__init_dialogs_controller.init_cancelled.connect(
                self.__initialization_cancelled
            )

            self.__db_config_dialog = ConnectionConfigDialog(
                model=self.__db_config_model,
                controller=self.__init_dialogs_controller,
            )

            self.__layer_select_dialog = LayersSelectDialog(
                model=self.__layers_config_model,
                controller=self.__init_dialogs_controller,
            )

            self.__cols_config_dialog = LayerColumnsDialog(
                model=self.__cols_config_model,
                controller=self.__init_dialogs_controller,
            )

            self.__db_config_dialog.open()
        else:
            self.__main_controller.open_main_window()
