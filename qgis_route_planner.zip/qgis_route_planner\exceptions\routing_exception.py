class RoutingException(Exception):
    pass