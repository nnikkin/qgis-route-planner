class BaseRestriction:
    pass
