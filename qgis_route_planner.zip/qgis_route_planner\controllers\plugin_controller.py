from ..data.models import DbConfigModel, LayerConfigModel, ColumnsConfigModel, SettingsModel, MainWindowModel
from ..repositories import (
    RoadGraphRepository,
    LayerRepository,
    VehicleProfileRepository,
    DbConnection,
)
from ..services import SpatialDataService, RoutingService, SettingsService
from ..views import PluginMainWindow, ConnectionConfigDialog, SettingsDialog, LayersSelectDialog, LayerColumnsDialog
from ..controllers import InitDialogsController, MainWindowController, SettingsWindowController

from qgis.PyQt.QtWidgets import QMessageBox

class PluginController:
    """Контроллер плагина"""
    def __init__(self):
        self.__db_config_model: DbConfigModel = DbConfigModel()
        self.__layers_config_model: LayerConfigModel = LayerConfigModel()
        self.__cols_config_model: ColumnsConfigModel = ColumnsConfigModel()
        self.__settings_model: SettingsModel = SettingsModel()
        self.__main_window_model: MainWindowModel = MainWindowModel()

        self.__main_window_controller: MainWindowController = None
        self.__settings_controller: SettingsWindowController = None
        #self.__restriction_controller: RestrictionWindowController = None
        self.__init_dialogs_controller: InitDialogsController = InitDialogsController(
            db_config_model=self.__db_config_model,
            layer_config_model=self.__layers_config_model,
            columns_config_model=self.__cols_config_model
        )

        self.__db_config_dialog: ConnectionConfigDialog = ConnectionConfigDialog(
            model=self.__db_config_model,
            controller=self.__init_dialogs_controller,
        )
        self.__layer_select_dialog: LayersSelectDialog = LayersSelectDialog(
            model=self.__layers_config_model,
            controller=self.__init_dialogs_controller,
        )
        self.__cols_config_dialog: LayerColumnsDialog = LayerColumnsDialog(
            model=self.__cols_config_model,
            controller=self.__init_dialogs_controller,
        )
        self.__main_window: PluginMainWindow = None
        self.__restriction_dialog = None
        self.__settings_dialog: SettingsDialog = None

        self.__db_connection: DbConnection = None

        self.__settings_service: SettingsService = None
        self.__spatial_data_service: SpatialDataService = None
        self.__routing_service: RoutingService = None
        #self.__restriction_service: RestrictionService = None

        self.__vehicle_repo: VehicleProfileRepository = None
        self.__layer_repo: LayerRepository = None
        self.__graph_repo: RoadGraphRepository = None
        #self.__restriction_repo: RestrictionRepository = None

        self.__old_db_connection: DbConnection = None
        self.__old_db_config_model: DbConfigModel = None
        self.__old_layers_config_model: LayerConfigModel = None
        self.__old_cols_config_model: ColumnsConfigModel = None

        self.__connect_signals()

    def first_start_initialize(self):
        self.__db_config_dialog.open()

    def open_main_window(self):
        self.__main_window.show()

    def __connect_signals(self):
        self.__init_dialogs_controller.con_test_requested.connect(self.__db_con_test)
        self.__init_dialogs_controller.con_params_obtained.connect(self.__db_con_created)
        self.__init_dialogs_controller.layers_selected.connect(self.__layers_selected)
        self.__init_dialogs_controller.columns_configured.connect(self.__columns_configured)
        self.__init_dialogs_controller.init_cancelled.connect(self.__initialization_cancelled)

    def __disconnect_signals(self):
        self.__init_dialogs_controller.con_test_requested.disconnect()
        self.__init_dialogs_controller.con_params_obtained.disconnect()
        self.__init_dialogs_controller.layers_selected.disconnect()
        self.__init_dialogs_controller.columns_configured.disconnect()
        self.__init_dialogs_controller.init_cancelled.disconnect()

    def __init_views(self):
        self.__main_window = PluginMainWindow(
            model=self.__main_window_model,
            controller=self.__main_window_controller
        )
        self.__settings_dialog = SettingsDialog(
            model=self.__settings_model,
            controller=self.__settings_controller
        )
        #self.__restriction_dialog =

    def __init_controllers(self):
        self.__settings_controller = SettingsWindowController(
            self.__settings_model,
            self.__settings_service
        )
        self.__settings_controller.reconnect_requested.connect(self.__on_reconnect_requested)
        self.__settings_controller.graph_rebuild_requested.connect(self.__on_graph_rebuild_requested)

        self.__main_window_controller = MainWindowController(
            self.__main_window_model,
            self.__settings_controller,
            self.__spatial_data_service,
            self.__routing_service,
        )
        # self.__restriction_controller = RestrictionController(self.__settings_dialog, self.__restriction_service)

    def __init_repositories(self):
        self.__vehicle_repo = VehicleProfileRepository(self.__db_connection)
        self.__layer_repo = LayerRepository(self.__db_connection)
        self.__graph_repo = RoadGraphRepository(self.__db_connection, self.__layer_repo)
        #self.__restriction_repo = RestrictionRepository(self.__db_connection)

    def __init_services(self):
        self.__settings_service = SettingsService(self.__vehicle_repo)
        self.__spatial_data_service = SpatialDataService(self.__layer_repo, self.__graph_repo, self.__vehicle_repo)
        self.__routing_service = RoutingService(self.__graph_repo)
        #self.__restriction_service = RestrictionService(self.__restriction_repo)

    def __init_everything(self):
        self.__init_repositories()
        self.__init_services()
        self.__init_controllers()
        self.__init_views()

    def __db_con_test(self):
        try:
            self.__db_connection = DbConnection(
                host=self.__db_config_model.host,
                port=self.__db_config_model.port,
                username=self.__db_config_model.username,
                password=self.__db_config_model.password,
                database=self.__db_config_model.database,
                schema=self.__db_config_model.schema,
            )

            if self.__db_connection.test_connection():
                self.__init_repositories()
                self.__init_services()
                self.__init_dialogs_controller.set_service(self.__spatial_data_service)

        except Exception as e:
            QMessageBox.critical(
                None,
                "Ошибка",
                f"Не удалось завершить инициализацию плагина:\n{e}",
                QMessageBox.Ok
            )

    def __db_con_created(self):
        try:
            self.__db_connection = DbConnection(
                host=self.__db_config_model.host,
                port=self.__db_config_model.port,
                username=self.__db_config_model.username,
                password=self.__db_config_model.password,
                database=self.__db_config_model.database,
                schema=self.__db_config_model.schema,
            )

            if self.__main_window_controller and self.__settings_controller:
                self.__main_window.close()
                self.__settings_dialog.close()

            self.__init_everything()
            self.__settings_service.save_db_params(self.__db_connection)
            self.__layer_select_dialog.open()
        except Exception as e:
            QMessageBox.critical(
                None,
                "Ошибка",
                f"Не удалось завершить инициализацию плагина:\n{e}",
                QMessageBox.Ok
            )

    def __layers_selected(self):
        self.__selected_layers = self.__layers_config_model.selected_layers
        self.__cols_config_dialog.open()

    def __columns_configured(self):
        self.__column_mapping = self.__cols_config_model.mappings
        self.__initialization_finished()

    def __initialization_finished(self):
        try:
            self.first_start = False
            self.__spatial_data_service.run_init_database(self.__selected_layers, self.__column_mapping)
        except Exception as e:
            QMessageBox.critical(
                None,
                "Ошибка",
                f"Не удалось завершить инициализацию плагина:\n{e}",
                QMessageBox.Ok
            )

        self.__main_window.show()
        self.__main_window_controller.initialize_map()

    def __initialization_cancelled(self):
        if self.__main_window_controller:
            self.__main_window.close()

        self.first_start = True
        self.__init_dialogs_controller = None

    def __on_graph_rebuild_requested(self):
        try:
            self.__main_window.close()
            self.__graph_repo.create_topology()
            self.__main_window.show()
            self.__main_window_controller.initialize_map()
            self.__settings_dialog.close()
        except Exception as e:
            QMessageBox.critical(None, "Ошибка", f"Не удалось перестроить граф:\n{e}", QMessageBox.Ok)

    def __on_reconnect_requested(self):
        """Обработчик запроса на переподключение к БД"""
        self.__old_db_connection = self.__db_connection
        self.__old_db_config_model = self.__db_config_model
        self.__old_layers_config_model = self.__layers_config_model
        self.__old_cols_config_model = self.__cols_config_model

        try:
            self.__db_connection = None
            self.__db_config_model = DbConfigModel()
            self.__layers_config_model = LayerConfigModel()
            self.__cols_config_model = ColumnsConfigModel()
            self.__init_dialogs_controller: InitDialogsController = InitDialogsController(
                db_config_model=self.__db_config_model,
                layer_config_model=self.__layers_config_model,
                columns_config_model=self.__cols_config_model
            )

            self.__connect_signals()
            self.__db_config_dialog.open()
        except Exception as e:
            QMessageBox.critical(
                None,
                "Ошибка",
                f"Во время переподключения произошла ошибка:\n{e}",
                QMessageBox.Ok
            )
            self.__reconnect_cancelled()

    def __reconnect_cancelled(self):
        self.__db_connection = self.__old_db_connection
        self.__db_config_model = self.__old_db_config_model
        self.__layers_config_model = self.__old_layers_config_model
        self.__cols_config_model = self.__old_cols_config_model
        self.__init_dialogs_controller: InitDialogsController = InitDialogsController(
            db_config_model=self.__db_config_model,
            layer_config_model=self.__layers_config_model,
            columns_config_model=self.__cols_config_model
        )

        self.__old_db_connection = None
        self.__old_db_config_model = None
        self.__old_layers_config_model = None
        self.__old_cols_config_model = None

        self.__connect_signals()

        self.__init_everything()

    def unload(self):
        if self.__main_window_controller is not None:
            self.__main_window_controller.on_clear_everything()
