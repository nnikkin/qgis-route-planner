# -*- coding: utf-8 -*-
from qgis.PyQt import QtCore, QtWidgets
from qgis.PyQt.QtCore import QObject, pyqtSlot
from qgis.PyQt.QtWidgets import QMessageBox, QDialog

from ..controllers import InitDialogsController
from ..data.models import LayerConfigModel
from ..data.models.layer_config_model import Layer
from ..utils import GeometryType, LayerRole


class LayersSelectDialog(QDialog):
    """Диалоговое окно выбора слоя для обработки"""

    def __init__(
            self,
            model: LayerConfigModel,
            controller: InitDialogsController,
            parent: QObject = None
    ):
        super().__init__(parent)

        self.__model: LayerConfigModel = model
        self.__controller: InitDialogsController = controller

        self.__available_layers: list = []

        self.setupUi()

    def __connect(self):
        self.pushItemToTableButton.clicked.connect(self.__on_push_to_table_clicked)
        self.pushItemToListButton.clicked.connect(self.__on_push_to_list_clicked)
        self.buttonBox.accepted.connect(self.__on_accept)
        self.buttonBox.rejected.connect(self.close)

        self.__model.layers_changed.connect(self.__update_layers_table)

        self.__controller.layers_selected.connect(self.accept)
        self.__controller.layer_selection_failed.connect(self.__on_layer_selection_failed)

    def setupUi(self):
        self.setObjectName("SelectLayersDialog")
        self.resize(800, 400)

        self.verticalLayout = QtWidgets.QVBoxLayout(self)
        self.verticalLayout.setObjectName("verticalLayout")

        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")

        self.label = QtWidgets.QLabel(self)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)

        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")

        self.listWidget = QtWidgets.QListWidget(self)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.listWidget.sizePolicy().hasHeightForWidth())

        self.listWidget.setSizePolicy(sizePolicy)
        self.listWidget.setObjectName("listWidget")

        self.horizontalLayout.addWidget(self.listWidget)

        self.verticalLayout_2 = QtWidgets.QVBoxLayout()
        self.verticalLayout_2.setSizeConstraint(QtWidgets.QLayout.SizeConstraint.SetMinimumSize)
        self.verticalLayout_2.setContentsMargins(-1, -1, 0, -1)
        self.verticalLayout_2.setObjectName("verticalLayout_2")

        self.pushItemToTableButton = QtWidgets.QPushButton(self)
        self.pushItemToTableButton.setObjectName("pushItemToTableButton")
        self.verticalLayout_2.addWidget(self.pushItemToTableButton)

        self.pushItemToListButton = QtWidgets.QPushButton(self)
        self.pushItemToListButton.setObjectName("pushItemToListButton")
        self.verticalLayout_2.addWidget(self.pushItemToListButton)

        self.horizontalLayout.addLayout(self.verticalLayout_2)

        self.tableWidget = QtWidgets.QTableWidget(self)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.MinimumExpanding, QtWidgets.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.tableWidget.sizePolicy().hasHeightForWidth())

        self.tableWidget.setSizePolicy(sizePolicy)
        self.tableWidget.setSizeIncrement(QtCore.QSize(0, 0))
        self.tableWidget.setProperty("showDropIndicator", False)
        self.tableWidget.setDragDropOverwriteMode(False)
        self.tableWidget.setAlternatingRowColors(False)
        self.tableWidget.setCornerButtonEnabled(True)
        self.tableWidget.setColumnCount(3)
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setRowCount(0)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(2, item)
        self.tableWidget.horizontalHeader().setSortIndicatorShown(False)
        self.tableWidget.horizontalHeader().setStretchLastSection(True)
        self.tableWidget.verticalHeader().setSortIndicatorShown(False)
        self.tableWidget.verticalHeader().setStretchLastSection(False)
        self.tableWidget.setSelectionMode(QtWidgets.QAbstractItemView.SelectionMode.SingleSelection)
        self.tableWidget.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectionBehavior.SelectRows)
        self.horizontalLayout.addWidget(self.tableWidget)

        self.gridLayout.addLayout(self.horizontalLayout, 1, 0, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)

        self.buttonBox = QtWidgets.QDialogButtonBox(self)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.buttonBox.sizePolicy().hasHeightForWidth())

        self.buttonBox.setSizePolicy(sizePolicy)
        self.buttonBox.setOrientation(QtCore.Qt.Orientation.Horizontal)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.StandardButton.Cancel |
                                          QtWidgets.QDialogButtonBox.StandardButton.Ok)
        self.buttonBox.setCenterButtons(False)
        self.buttonBox.setObjectName("buttonBox")
        self.verticalLayout.addWidget(self.buttonBox)

        self.setTabOrder(self.listWidget, self.pushItemToTableButton)
        self.setTabOrder(self.pushItemToTableButton, self.pushItemToListButton)
        self.setTabOrder(self.pushItemToListButton, self.tableWidget)

        self.retranslateUi()
        QtCore.QMetaObject.connectSlotsByName(self)
        self.__connect()

    def retranslateUi(self):
        _translate = QtCore.QCoreApplication.translate
        self.setWindowTitle(_translate("Dialog", "Шаг 2: выбор таблицы"))
        self.label.setText(_translate("Dialog", "Выберите слои с геометрией LineString из базы данных для обработки."))
        self.pushItemToTableButton.setText(_translate("Dialog", ">>"))
        self.pushItemToListButton.setText(_translate("Dialog", "<<"))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("Dialog", "Название таблицы"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("Dialog", "Тип геометрии"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("Dialog", "Роль слоя"))

    def showEvent(self, event, **kwargs):
        super().showEvent(event)
        if not self.__available_layers:
            self.__fill_list()

    def closeEvent(self, event, **kwargs):
        close_question = QMessageBox.question(
            self,
            "Внимание",
            "Для продолжения требуется выбрать таблицу.\nВы уверены, что хотите закрыть мастер подключения?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        if close_question == QMessageBox.Yes:
            self.__controller.initialization_cancelled()
            event.accept()
        else:
            event.ignore()

    def __on_push_to_table_clicked(self):
        selected_item = self.listWidget.currentItem()
        if not selected_item:
            QMessageBox.warning(self, "Ошибка", "Выберите значение из списка слева.", QMessageBox.Ok)
            return
        layer_name = selected_item.text()
        self.__controller.add_layer_to_config(layer_name, GeometryType.LINESTRING, LayerRole.ROADS)

    def __on_push_to_list_clicked(self):
        selected_rows = self.tableWidget.selectionModel().selectedRows()

        if not selected_rows:
            QMessageBox.warning(self, "Ошибка", "Выберите строку в таблице справа.", QMessageBox.Ok)
            return

        self.__controller.remove_layer_from_config(selected_rows[0].row())

    def __on_accept(self):
        self.__controller.layer_select_step_finish()

    @pyqtSlot(str)
    def __on_layer_selection_failed(self, message: str):
        QMessageBox.warning(self, "Ошибка", message, QMessageBox.Ok)

    def __on_combobox_geom_changed(self, row, text):
        geom_type = GeometryType.from_value(text)
        self.__controller.change_geometry_type(row, geom_type)

    def __on_combobox_role_changed(self, row, text):
        role = LayerRole.from_value(text)
        self.__controller.change_layer_role(row, role)

    @pyqtSlot(list)
    def __update_layers_table(self, layers: list):
        self.tableWidget.blockSignals(True)
        self.tableWidget.setRowCount(0)

        for row, layer in enumerate(layers):
            self.__create_table_row(layer)

        self.listWidget.clear()
        chosen_names = {l.name for l in layers}
        for name in self.__available_layers:
            if name not in chosen_names:
                self.listWidget.addItem(name)

        self.tableWidget.blockSignals(False)

    def __create_role_combobox(self, role: LayerRole = LayerRole.ROADS):
        roleComboBox = QtWidgets.QComboBox()
        roleComboBox.setObjectName("roleComboBox")
        for index, e in enumerate(LayerRole):
            roleComboBox.addItem(e.value)
            if e == role:
                roleComboBox.setCurrentIndex(index)
        return roleComboBox

    def __create_geometry_combobox(self, geom_type: GeometryType = GeometryType.LINESTRING):
        geometryComboBox = QtWidgets.QComboBox()
        geometryComboBox.setObjectName("geometryComboBox")

        for index, e in enumerate(GeometryType):
            geometryComboBox.addItem(e.value)
            if e == geom_type:
                geometryComboBox.setCurrentIndex(index)
        return geometryComboBox

    def __create_table_row(self, layer: Layer):
        row_count = self.tableWidget.rowCount()

        geometry_cbox = self.__create_geometry_combobox(layer.geom_type)
        role_cbox = self.__create_role_combobox(layer.role)

        geometry_cbox.currentTextChanged.connect(
            lambda text, r=row_count: self.__on_combobox_geom_changed(r, text)
        )
        role_cbox.currentTextChanged.connect(
            lambda text, r=row_count: self.__on_combobox_role_changed(r, text)
        )

        self.tableWidget.insertRow(row_count)
        self.tableWidget.setItem(row_count, 0, QtWidgets.QTableWidgetItem(layer.name))
        self.tableWidget.setCellWidget(row_count, 1, geometry_cbox)
        self.tableWidget.setCellWidget(row_count, 2, role_cbox)

    def __fill_list(self):
        layers = self.__controller.get_layers()
        self.__available_layers = layers
        self.listWidget.addItems(self.__available_layers)
