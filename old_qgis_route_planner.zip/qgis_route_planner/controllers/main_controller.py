from qgis.PyQt.QtWidgets import QMessageBox
from qgis_route_planner.controllers.settings_controller import SettingsController
from qgis_route_planner.repositories.db_connection import DbConnection
from qgis_route_planner.services.settings_service import SettingsService
from qgis_route_planner.views.main_view import PluginMainWindow
from qgis_route_planner.views.settings_view import SettingsDialog
from qgis_route_planner.views.dbconn_view import InitDbSettingsDialog


class MainController:
    """Контроллер главного окна плагина."""

    def __init__(
            self,
            main_window: PluginMainWindow,
            settings_dialog: SettingsDialog,
            settings_controller: SettingsController,
            settings_service: SettingsService,
    ):
        self.__main_window = main_window
        self.__settings_dialog = settings_dialog
        self.__settings_controller = settings_controller
        self.__settings_service = settings_service
        self.__connected = False

        self.__connect_signals()

    def __connect_signals(self):
        self.__main_window.profiles_action.triggered.connect(lambda: self.__open_settings_dialog(1))
        self.__main_window.db_action.triggered.connect(lambda: self.__open_settings_dialog())

    def __open_settings_dialog(self, tab_index: int = 0):
        """Открывает окно настроек на нужной вкладке."""
        self.__settings_controller.set_current_tab_active(tab_index)
        self.__settings_dialog.show()
        self.__settings_dialog.raise_()
        self.__settings_dialog.activateWindow()

    def initialize(self) -> DbConnection | None:
        """Проверяет подключение и открывает настройки, если БД не настроена."""
        self.__connected = False
        db_con = self.__settings_service.resolve_db_params()

        while True:
            if db_con is None or not db_con.is_complete():
                QMessageBox.warning(
                    self.__main_window,
                    "Внимание",
                    (
                        "Не удалось получить строку подключения из QGIS.\n"
                        "Пожалуйста, введите параметры для подключения к базе данных."
                    ),
                    QMessageBox.Ok
                )

                db_params = self.__show_connection_dialog(db_con)
                if db_params is None:
                    return None
                try:
                    db_con = DbConnection(**db_params)
                except Exception as exc:
                    QMessageBox.warning(
                        self.__main_window,
                        "Внимание",
                        f"Не удалось создать подключение к базе данных: {exc}",
                        QMessageBox.Ok
                    )
                    db_con = None
                continue

            self.__connected = self.__settings_service.test_connection(db_con)
            if self.__connected:
                break

            QMessageBox.warning(
                self.__main_window,
                "Внимание",
                "Не удалось подключиться к базе данных. Проверьте параметры подключения.",
                QMessageBox.Ok
            )
            db_params = self.__show_connection_dialog(db_con)
            if db_params is None:
                return None
            try:
                db_con = DbConnection(**db_params)
            except Exception as exc:
                QMessageBox.warning(
                    self.__main_window,
                    "Внимание",
                    f"Не удалось создать подключение к базе данных: {exc}",
                    QMessageBox.Ok
                )
                db_con = None

        self.__settings_service.save_db_params(db_con)
        return db_con

    def __show_connection_dialog(self, init_params=None) -> dict | None:
        dialog = InitDbSettingsDialog(self.__main_window, initial_params=init_params)
        if dialog.exec_():
            return dict(
                host=dialog.host_edit.text(),
                port=int(dialog.port_edit.text()),
                database=dialog.database_edit.text() if hasattr(dialog, 'database_edit') else '',
                username=dialog.username_edit.text(),
                password=dialog.password_edit.text()
            )
        return None
