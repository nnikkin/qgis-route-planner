from dataclasses import dataclass

import psycopg


class DbConnection:
    """Низкоуровневый класс для работы с БД."""

    def __init__(self, host: str, port: int, database: str, username: str, password: str):
        self.__host = host
        self.__port = port
        self.__database = database
        self.__username = username
        self.__password = password
        self.__connection = None

    @property
    def host(self) -> str:
        return self.__host

    @property
    def port(self) -> int:
        return self.__port

    @property
    def database(self) -> str:
        return self.__database

    @property
    def username(self) -> str:
        return self.__username

    @property
    def password(self) -> str:
        return self.__password

    def __create_connection(self):
        """Создает новое соединение."""
        kwargs = dict(
            host=self.__host,
            port=self.__port,
            dbname=self.__database,
            user=self.__username,
        )
        if self.__password:
            kwargs["password"] = self.__password
        return psycopg.connect(**kwargs)

    def close(self):
        if self.__connection:
            self.__connection.close()
            self.__connection = None

    def connect(self):
        """Открывает и сохраняет соединение для явного использования."""
        self.__connection = self.__create_connection()
        return self.__connection

    def execute_query(self, query: str, params: list = None):
        """Выполнить запрос с возвратом строк (SELECT)"""
        with self.__create_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(query, params)
                return cursor.fetchall()

    def execute_nquery(self, query: str, params: list = None):
        """Выполнить запрос без возврата строк (INSERT/DELETE/UPDATE)"""
        with self.__create_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(query, params)

    def test_connection(self) -> bool:
        """Проверяет возможность подключения"""
        try:
            with self.__create_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute("SELECT 1;")
                    cursor.fetchall()
            return True
        except Exception:
            return False

    def is_complete(self) -> bool:
        return all([self.__host, self.__port, self.__database, self.__username])
