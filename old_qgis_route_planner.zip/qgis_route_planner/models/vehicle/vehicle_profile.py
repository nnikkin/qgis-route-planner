from dataclasses import dataclass


@dataclass
class VehicleProfile:
    name: str = ""
    plate: str = ""
    height: float = 0.0
    width: float = 0.0
    weight: float = 0.0
    max_speed: float = 0.0
