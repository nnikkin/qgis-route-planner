from qgis.core import QgsPointXY

from qgis_route_planner.models.route.point_type import PointType
from qgis_route_planner.models.route.route_point import Point


class RoutePointCollection:
    """Хранилище точек маршрута без UI-логики."""

    def __init__(self):
        self.__next_point_id = 1
        self.__points: list[Point] = []

    @property
    def points(self) -> list[Point]:
        return list(self.__points)

    def _reindex(self):
        for index, point in enumerate(self.__points):
            point.order = index

    def _insert_order(self, point_type: PointType) -> int:
        if point_type == PointType.START:
            for point in self.__points:
                point.order += 1
            return 0

        if point_type == PointType.END:
            return len(self.__points)

        end_point_index = next((i for i, point in enumerate(self.__points) if point.point_type == PointType.END), None)
        if end_point_index is None:
            return len(self.__points)
        return end_point_index

    def add_point(self, point: QgsPointXY, point_type: PointType, node_id: int) -> Point:
        order = self._insert_order(point_type)
        route_point = Point(
            id=self.__next_point_id,
            point=point,
            point_type=point_type,
            order=order,
            node_id=node_id,
        )

        self.__next_point_id += 1
        self.__points.append(route_point)
        self.__points.sort(key=lambda p: p.order)
        self._reindex()
        return route_point

    def remove_point(self, point_id: int) -> Point | None:
        point = next((p for p in self.__points if p.id == point_id), None)
        if not point:
            return None

        self.__points.remove(point)
        self._reindex()
        return point

    def clear(self):
        self.__points.clear()
        self.__next_point_id = 1

    def change_point_type(self, point_id: int, new_type: PointType) -> Point | None:
        point = next((p for p in self.__points if p.id == point_id), None)
        if not point:
            return None

        point.point_type = new_type
        self.__points.sort(key=lambda p: (
            0 if p.point_type == PointType.START else 2 if p.point_type == PointType.END else 1,
            p.order,
        ))
        self._reindex()
        return point

    def has_required_points(self) -> bool:
        return any(p.point_type == PointType.START for p in self.__points) and any(
            p.point_type == PointType.END for p in self.__points
        )

    def get_point(self, point_id: int) -> Point | None:
        return next((p for p in self.__points if p.id == point_id), None)
