import os

from qgis.PyQt.QtCore import QCoreApplication, QSettings, QTranslator
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMainWindow

from qgis_route_planner.controllers.main_controller import MainController
from qgis_route_planner.controllers.map_controller import MapController
from qgis_route_planner.controllers.restriction_controller import RestrictionController
from qgis_route_planner.controllers.settings_controller import SettingsController
from qgis_route_planner.repositories.db_connection import DbConnection
from qgis_route_planner.repositories.graph_repository import RoadGraphRepository
from qgis_route_planner.repositories.layer_repository import LayerRepository
from qgis_route_planner.repositories.restriction_repository import RestrictionRepository
from qgis_route_planner.repositories.vehicle_repository import VehicleProfileRepository
from qgis_route_planner.services.database_service import DatabaseService
from qgis_route_planner.services.map_service import MapService
from qgis_route_planner.services.restriction_service import RestrictionService
from qgis_route_planner.services.routing_service import RoutingService
from qgis_route_planner.services.settings_service import SettingsService
from qgis_route_planner.views.main_view import PluginMainWindow
from qgis_route_planner.views.settings_view import SettingsDialog


class QgisRoutePlanner:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.actions = []
        self.menu = self.tr(u"&Планировщик маршрутов")
        self.first_start = True

        self._conn = None
        self._main_window = None
        self._main_window_scaffold = None
        self._settings_dialog = None

        self._settings_service = None
        self._settings_controller = None

        self._vehicle_repo = None
        self._layer_repo = None
        self._graph_repo = None
        self._restriction_repo = None

        self._database_service = None
        self._routing_service = None
        self._restriction_service = None
        self._map_service = None

        self._main_controller = None
        self._restriction_controller = None
        self._map_controller = None

        locale = QSettings().value("locale/userLocale")
        locale_path = os.path.join(self.plugin_dir, "i18n", f"QgisRoutePlanner_{locale}.qm")
        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

    def tr(self, message):
        return QCoreApplication.translate("QgisRoutePlanner", message)

    def add_action(
            self,
            icon_path,
            text,
            callback,
            enabled_flag=True,
            add_to_menu=True,
            add_to_toolbar=True,
            status_tip=None,
            whats_this=None,
            parent=None,
    ):
        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)
        if whats_this is not None:
            action.setWhatsThis(whats_this)
        if add_to_toolbar:
            self.iface.addToolBarIcon(action)
        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action)

        self.actions.append(action)
        return action

    def initGui(self):
        icon_path = ":/plugins/qgis_route_planner/icon.png"
        self.add_action(
            icon_path,
            text=self.tr(u"Планировщик маршрутов"),
            callback=self.run,
            parent=self.iface.mainWindow(),
        )
        self.first_start = True

    def unload(self):
        if self._conn:
            try:
                self._conn.close()
            except Exception as e:
                print(f"Не удалось закрыть подключение к базе данных: {e}")

        for action in self.actions:
            self.iface.removePluginMenu(self.tr(u"&Планировщик маршрутов"), action)
            self.iface.removeToolBarIcon(action)

    def _init_database_connection(self, settings: DbConnection) -> bool:
        try:
            self._conn = settings
            return self._conn.test_connection()
        except Exception as e:
            print(f"Не удалось подключиться к базе данных: {e}")
            return False

    def _build_runtime_services(self, db_settings: DbConnection):
        self._vehicle_repo = VehicleProfileRepository(db_settings)
        self._layer_repo = LayerRepository(db_settings)
        self._graph_repo = RoadGraphRepository(db_settings, self._layer_repo)
        #self._restriction_repo = RestrictionRepository(db_settings)

        self._database_service = DatabaseService(self._layer_repo, self._graph_repo, self._vehicle_repo)
        self._routing_service = RoutingService(self._graph_repo)
        #self._restriction_service = RestrictionService(self._restriction_repo)
        self._map_service = MapService(self._database_service)

    def run(self):
        if self.first_start:
            self.first_start = False

            self._main_window_scaffold = QMainWindow()
            self._main_window = PluginMainWindow()
            self._main_window.setupUi(self._main_window_scaffold)

            self._settings_dialog = SettingsDialog()
            self._settings_dialog.setupUi(self._settings_dialog)

            self._settings_service = SettingsService()
            self._settings_controller = SettingsController(self._settings_dialog, self._settings_service)
            self._main_controller = MainController(
                self._main_window,
                self._settings_dialog,
                self._settings_controller,
                self._settings_service,
            )

            db_settings = self._main_controller.initialize()
            if db_settings is None:
                self.first_start = True
                return

            if not self._init_database_connection(db_settings):
                self.first_start = True
                return

            self._build_runtime_services(db_settings)
            #self._restriction_controller = RestrictionController(self._settings_dialog, self._restriction_service)
            self._settings_controller.settings_saved.connect(self.__on_database_settings_saved)

            if self._map_service and self._routing_service: #and self._restriction_service:
                self._map_controller = MapController(
                    self._main_window,
                    self._map_service,
                    self._routing_service,
                    None,
                )
                self._map_controller.initialize_map()

            self._database_service.run_init_database()

        if self._map_controller:
            self._map_controller.initialize_map()
        self._main_window_scaffold.show()

    def __on_database_settings_saved(self, db_connection: DbConnection):
        self._conn = db_connection
        self._build_runtime_services(db_connection)

        #if not self._restriction_controller:
        #    self._restriction_controller = RestrictionController(self._settings_dialog, self._restriction_service)
        #else:
        #    self._restriction_controller.reload()

        if not self._map_controller and self._main_window and self._routing_service and self._restriction_service:
            self._map_controller = MapController(
                self._main_window,
                self._map_service,
                self._routing_service,
                None,
            )

        if self._map_controller:
            self._map_controller.initialize_map()
