from qgis.core import QgsVectorLayer

from qgis_route_planner.services.database_service import DatabaseService


class MapService:
    """Тонкий сервис для получения картографических слоев."""

    def __init__(self, database_service: DatabaseService):
        self.__database_service = database_service

    def load_all_spatial_layers(self, schema: str = "public") -> list[QgsVectorLayer]:
        return self.__database_service.load_all_spatial_layers(schema=schema)
