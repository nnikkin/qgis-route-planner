from qgis.PyQt.QtCore import QSettings

from qgis_route_planner.models.vehicle.vehicle_profile import VehicleProfile
from qgis_route_planner.repositories.db_connection import DbConnection
from qgis_route_planner.repositories.vehicle_repository import VehicleProfileRepository


class SettingsService:
    """Сервис для работы с настройками плагина"""

    __settings_FILE = "qgis_route_planner.ini"
    _GROUP_DB = "database"

    def __init__(self, vehicle_repo: VehicleProfileRepository | None = None):
        self.__settings = QSettings(self.__settings_FILE, QSettings.IniFormat)
        self.__vehicle_repo = vehicle_repo

    def set_vehicle_repository(self, db: DbConnection | VehicleProfileRepository | None):
        """Привязывает репозиторий профилей к текущему подключению."""
        if isinstance(db, VehicleProfileRepository):
            self.__vehicle_repo = db
        elif isinstance(db, DbConnection):
            self.__vehicle_repo = VehicleProfileRepository(db)
        else:
            self.__vehicle_repo = None

    def load_db_params(self) -> DbConnection | None:
        """Загружает параметры БД из настроек"""
        self.__settings.beginGroup(self._GROUP_DB)

        host = self.__settings.value("host", "localhost")
        port = self.__settings.value("port", "5432")
        database = self.__settings.value("database", "")
        username = self.__settings.value("username", "")
        password = self.__settings.value("password", "")

        self.__settings.endGroup()

        db = DbConnection(host, int(port), database, username, password)
        return db if db.is_complete() else None

    def save_db_params(self, db: DbConnection):
        """Сохраняет параметры БД в настройки"""
        self.__settings.beginGroup(self._GROUP_DB)
        self.__settings.setValue("host", db.host)
        self.__settings.setValue("port", db.port)
        self.__settings.setValue("database", db.database)
        self.__settings.setValue("username", db.username)
        self.__settings.setValue("password", db.password)
        self.__settings.endGroup()
        self.__settings.sync()

    def __try_get_from_qgis_connections(self, conn_name: str = "postgres") -> DbConnection | None:
        """Пытается получить параметры из сохраненных подключений QGIS"""
        s = QSettings("QGIS")
        s.beginGroup("PostgreSQL/connections")

        host = s.value(f"{conn_name}/host")
        if not host:
            s.endGroup()
            return None

        params = DbConnection(
            host=host,
            port=s.value(f"{conn_name}/port", "5432"),
            database=s.value(f"{conn_name}/database", ""),
            username=s.value(f"{conn_name}/username", ""),
            password=s.value(f"{conn_name}/password", ""),
        )
        s.endGroup()

        return params if params.is_complete() else None

    def resolve_db_params(self) -> DbConnection | None:
        return self.load_db_params() or self.__try_get_from_qgis_connections()

    def test_connection(self, con: DbConnection) -> bool:
        return con.test_connection()

    def get_all_profiles(self) -> list[dict]:
        """Получить все профили"""
        if not self.__vehicle_repo:
            return []
        return self.__vehicle_repo.get_all()

    def get_profile_by_id(self, profile_id: int) -> dict | None:
        """Получить профиль по ID"""
        if not self.__vehicle_repo:
            return None
        return self.__vehicle_repo.get_by_id(profile_id)

    def create_profile(self, profile: VehicleProfile) -> bool:
        """Создать новый профиль"""
        if not self.__vehicle_repo:
            return False
        try:
            self.__vehicle_repo.add_profile(profile)
            return True
        except Exception as e:
            raise Exception(f"Ошибка создания профиля: {str(e)}")

    def update_profile(self, profile_id: int, profile: VehicleProfile) -> bool:
        """Обновить профиль"""
        if not self.__vehicle_repo:
            return False
        try:
            self.__vehicle_repo.upd_profile(profile_id, profile)
            return True
        except Exception as e:
            raise Exception(f"Ошибка обновления профиля: {str(e)}")

    def delete_profile(self, profile_id: int) -> bool:
        """Удалить профиль"""
        if not self.__vehicle_repo:
            return False
        try:
            self.__vehicle_repo.del_profile(profile_id)
            return True
        except Exception as e:
            raise Exception(f"Ошибка удаления профиля: {str(e)}")
