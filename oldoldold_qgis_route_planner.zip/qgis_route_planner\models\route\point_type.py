class PointType:
    START = "start"
    WAYPOINT = "waypoint"
    END = "end"