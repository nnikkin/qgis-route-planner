# -*- coding: utf-8 -*-
import os
from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMainWindow

from qgis_route_planner.controllers.main_controller import MainController
from qgis_route_planner.controllers.settings_controller import SettingsController
from qgis_route_planner.repositories.layer_repository import LayerRepository
from qgis_route_planner.repositories.road_graph_repository import RoadGraphRepository
from qgis_route_planner.repositories.db_connection import DbConnection
from qgis_route_planner.services.routing_service import RoutingService
from qgis_route_planner.services.settings_service import SettingsService
from qgis_route_planner.views.main_view import PluginMainWindow


class QgisRoutePlanner:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        """
        :param iface: An interface instance that will be passed to this class
            which provides the hook by which you can manipulate the QGIS
            application at run time.
        :type iface: QgsInterface
        """
        self._road_graph_repo = None
        self._conn = None
        self._main_window = None
        self._main_window_scaffold = None
        self._graph_repo = None
        self._settings_service = None
        self._routing_service = None
        self._settings_controller = None
        self._main_controller = None

        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        locale = QSettings().value('locale/userLocale')
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'QgisRoutePlanner_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&Планировщик маршрутов')

        # Check if plugin was started the first time in current QGIS session
        # Must be set in initGui() to survive plugin reloads
        self.first_start = True

    def tr(self, message):
        """Получает перевод строки с помощью API перевода Qt.

        :param message: String for translation.
        :type message: str, QString

        :returns: Translated version of message.
        :rtype: QString
        """
        return QCoreApplication.translate('QgisRoutePlanner', message)

    def add_action(
            self,
            icon_path,
            text,
            callback,
            enabled_flag=True,
            add_to_menu=True,
            add_to_toolbar=True,
            status_tip=None,
            whats_this=None,
            parent=None):
        """Add a toolbar icon to the toolbar.

        :param icon_path: Path to the icon for this action. Can be a resource
            path (e.g. ':/plugins/foo/bar.png') or a normal file system path.
        :type icon_path: str

        :param text: Text that should be shown in menu items for this action.
        :type text: str

        :param callback: Function to be called when the action is triggered.
        :type callback: function

        :param enabled_flag: A flag indicating if the action should be enabled
            by default. Defaults to True.
        :type enabled_flag: bool

        :param add_to_menu: Flag indicating whether the action should also
            be added to the menu. Defaults to True.
        :type add_to_menu: bool

        :param add_to_toolbar: Flag indicating whether the action should also
            be added to the toolbar. Defaults to True.
        :type add_to_toolbar: bool

        :param status_tip: Optional text to show in a popup when mouse pointer
            hovers over the action.
        :type status_tip: str

        :param parent: Parent widget for the new action. Defaults None.
        :type parent: QWidget

        :param whats_this: Optional text to show in the status bar when the
            mouse pointer hovers over the action.

        :returns: The action that was created. Note that the action is also
            added to self.actions list.
        :rtype: QAction
        """

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            self.iface.addToolBarIcon(action)

        if add_to_menu:
            self.iface.addPluginToMenu(
                self.menu,
                action)

        self.actions.append(action)

        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""

        icon_path = ':/plugins/qgis_route_planner/icon.png'
        self.add_action(
            icon_path,
            text=self.tr(u'Планировщик маршрутов'),
            callback=self.run,
            parent=self.iface.mainWindow())

        # will be set False in run()
        self.first_start = True

    def unload(self):
        """Здесь описывается, что будет происходить при выгрузке расширения"""
        # Закрываем соединение с БД если оно открыто
        if self._conn:
            try:
                self._conn.close()
            except:
                pass

        for action in self.actions:
            self.iface.removePluginMenu(
                self.tr(u'&Планировщик маршрутов'),
                action)
            self.iface.removeToolBarIcon(action)

    def _init_database_connection(self, settings: DbConnection) -> bool:
        """Инициализирует соединение с БД на основе настроек"""
        try:
            self._conn = settings

            # Проверяем соединение
            if not self._conn.test_connection():
                return False

            return True
        except Exception as e:
            print(f"Failed to connect to database: {e}")
            return False

    def run(self):
        """Здесь описываются действия при запуске расширения"""
        if self.first_start:
            self.first_start = False
            self._main_window_scaffold = QMainWindow()
            self._main_window = PluginMainWindow()
            self._main_window.setupUi(self._main_window_scaffold)

            # Инициализируем сервисы
            self._settings_service = SettingsService()

            # Загружаем сохраненные настройки БД
            db_settings = self._settings_service.load_db_params()

            # Пытаемся подключиться к БД
            if db_settings and self._init_database_connection(db_settings):
                self._layer_repo = LayerRepository(db_settings)
                self._graph_repo = RoadGraphRepository(db_settings, self._layer_repo)
                self._routing_service = RoutingService(self._graph_repo)
            else:
                self._layer_repo = None
                self._graph_repo = None
                self._routing_service = None

            self._settings_controller = SettingsController(self._settings_service)

            self._main_controller = MainController(
                self._main_window,
                self._settings_controller,
                self._settings_service,
                self._routing_service,
                self._graph_repo
            )

            # Инициализируем (покажет диалог при необходимости)
            if not self._main_controller.initialize():
                # Не удалось настроить подключение
                return

        self._main_window_scaffold.show()