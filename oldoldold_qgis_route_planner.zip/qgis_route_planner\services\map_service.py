# map_service.py
from qgis.core import QgsDataSourceUri, QgsVectorLayer
from qgis_route_planner.repositories.layer_repository import LayerRepository
from qgis_route_planner.repositories.db_connection import DbConnection


class MapService:
    """Сервис для работы с картой и слоями"""

    def __init__(self, db_connection: DbConnection, layer_repo: LayerRepository):
        self._db_connection = db_connection
        self._layer_repo = layer_repo

    def load_layer_from_db(self, table_name: str, schema: str = 'public',
                           geom_col: str = 'geom', key_col: str = 'id') -> QgsVectorLayer:
        """Загружает слой из БД по имени таблицы"""
        if not self._db_connection.is_complete():
            raise ValueError("Database connection is not configured")

        uri = QgsDataSourceUri()
        uri.setConnection(
            self._db_connection.host,
            str(self._db_connection.port),
            self._db_connection.database,
            self._db_connection.username,
            self._db_connection.password
        )
        uri.setDataSource(aSchema=schema, aTable=table_name, aGeometryColumn=geom_col, aKeyColumn=key_col)

        # Создаем слой
        layer_name = f"{schema}.{table_name}"
        layer = QgsVectorLayer(uri.uri(False), layer_name, "postgres")

        if not layer.isValid():
            error = layer.error().message() if hasattr(layer, 'error') else "Unknown error"
            raise IOError(f"Layer {layer_name} failed to load! Error: {error}")

        # Включаем отображение слоя
        layer.setCrs(layer.crs())

        # Настройки отображения по умолчанию
        if layer.geometryType() == 0:  # Point
            layer.setOpacity(1.0)
        elif layer.geometryType() == 1:  # Line
            layer.setOpacity(1.0)
        elif layer.geometryType() == 2:  # Polygon
            layer.setOpacity(0.7)

        print(f"Layer {layer_name} loaded successfully. Feature count: {layer.featureCount()}")
        return layer

    def load_all_spatial_layers(self, schema: str = 'public') -> list[QgsVectorLayer]:
        """Загружает все пространственные таблицы из схемы"""
        try:
            tables = self._layer_repo.get_all_spatial_tables(schema)
            print(f"Found {len(tables)} spatial tables in schema '{schema}'")

            if not tables:
                print("No spatial tables found. Check if schema exists and contains geometry columns.")
                return []

            layers = []
            for row in tables:
                schema_name, table_name, geom_col, geom_type, srid = row
                print()
                try:
                    layer = self.load_layer_from_db(table_name, schema_name, geom_col)
                    layers.append(layer)
                    print(f"Loaded layer: {schema_name}.{table_name} (type: {geom_type})")
                except Exception as e:
                    print(f"Failed to load {schema_name}.{table_name}: {e}")

            return layers
        except Exception as e:
            print(f"Error loading spatial layers: {e}")
            return []