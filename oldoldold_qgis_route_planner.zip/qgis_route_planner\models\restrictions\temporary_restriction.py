class TemporaryRestriction(BaseException):
    def __init__(self, x: int, y: int, ):
        self._x = x
        self._y = y