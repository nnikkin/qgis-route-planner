class VehicleProfile():
    def __init__(self, name:str, plate:str, height:float, width:float, weight:float, max_speed:float):
        self._name = name
        self._plate = plate
        self._height = height
        self._width = width
        self._weight = weight
        self._max_speed = max_speed

    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, name:str):
        self._name = name

    @property
    def plate(self):
        return self._plate

    @plate.setter
    def plate(self, plate:str):
        self._plate = plate

    @property
    def height(self):
        return self._height

    @height.setter
    def height(self, height:float):
        self._height = height

    @property
    def width(self):
        return self._width

    @width.setter
    def width(self, width:float):
        self._width = width

    @property
    def weight(self):
        return self._weight

    @weight.setter
    def weight(self, weight:float):
        self._weight = weight

    @property
    def max_speed(self):
        return self._max_speed

    @max_speed.setter
    def max_speed(self, max_speed:float):
        self._max_speed = max_speed