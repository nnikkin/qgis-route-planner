# dbconn_view.py
# -*- coding: utf-8 -*-

from qgis.PyQt import QtCore, QtWidgets
from qgis_route_planner.repositories.db_connection import DbConnection


class InitDbSettingsDialog(QtWidgets.QDialog):
    def __init__(self, parent=None, initial_params: DbConnection = None, error_text: str = None):
        super().__init__(parent)
        self.setupUi(self)

        if initial_params and initial_params.is_complete():
            self.host_edit.setText(initial_params.host)
            self.port_edit.setText(str(initial_params.port))
            self.username_edit.setText(initial_params.username)
            self.password_edit.setText(initial_params.password)

        if error_text:
            QtWidgets.QMessageBox.warning(self, "Ошибка подключения", error_text)

    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(400, 250)
        Dialog.setWindowTitle("Настройки подключения")

        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(Dialog.sizePolicy().hasHeightForWidth())
        Dialog.setSizePolicy(sizePolicy)
        self.gridLayout = QtWidgets.QGridLayout(Dialog)
        self.gridLayout.setObjectName("gridLayout")
        self.formLayout_3 = QtWidgets.QFormLayout()
        self.formLayout_3.setObjectName("formLayout_3")

        self.label_12 = QtWidgets.QLabel(Dialog)
        self.label_12.setObjectName("label_12")
        self.formLayout_3.setWidget(0, QtWidgets.QFormLayout.ItemRole.LabelRole, self.label_12)
        self.host_edit = QtWidgets.QLineEdit(Dialog)
        self.host_edit.setObjectName("host_edit")
        self.formLayout_3.setWidget(0, QtWidgets.QFormLayout.ItemRole.FieldRole, self.host_edit)

        self.label_13 = QtWidgets.QLabel(Dialog)
        self.label_13.setObjectName("label_13")
        self.formLayout_3.setWidget(1, QtWidgets.QFormLayout.ItemRole.LabelRole, self.label_13)
        self.port_edit = QtWidgets.QLineEdit(Dialog)
        self.port_edit.setObjectName("port_edit")
        self.formLayout_3.setWidget(1, QtWidgets.QFormLayout.ItemRole.FieldRole, self.port_edit)

        self.label_14 = QtWidgets.QLabel(Dialog)
        self.label_14.setObjectName("label_14")
        self.formLayout_3.setWidget(2, QtWidgets.QFormLayout.ItemRole.LabelRole, self.label_14)
        self.database_edit = QtWidgets.QLineEdit(Dialog)
        self.database_edit.setObjectName("database_edit")
        self.formLayout_3.setWidget(2, QtWidgets.QFormLayout.ItemRole.FieldRole, self.database_edit)

        self.label_15 = QtWidgets.QLabel(Dialog)
        self.label_15.setObjectName("label_15")
        self.formLayout_3.setWidget(3, QtWidgets.QFormLayout.ItemRole.LabelRole, self.label_15)
        self.username_edit = QtWidgets.QLineEdit(Dialog)
        self.username_edit.setEchoMode(QtWidgets.QLineEdit.EchoMode.Normal)
        self.username_edit.setObjectName("username_edit")
        self.formLayout_3.setWidget(3, QtWidgets.QFormLayout.ItemRole.FieldRole, self.username_edit)

        self.label_16 = QtWidgets.QLabel(Dialog)
        self.label_16.setObjectName("label_16")
        self.formLayout_3.setWidget(4, QtWidgets.QFormLayout.ItemRole.LabelRole, self.label_16)
        self.password_edit = QtWidgets.QLineEdit(Dialog)
        self.password_edit.setMaxLength(32767)
        self.password_edit.setEchoMode(QtWidgets.QLineEdit.EchoMode.Password)
        self.password_edit.setObjectName("password_edit")
        self.formLayout_3.setWidget(4, QtWidgets.QFormLayout.ItemRole.FieldRole, self.password_edit)
        self.gridLayout.addLayout(self.formLayout_3, 0, 0, 1, 1)

        self.buttonBox = QtWidgets.QDialogButtonBox(Dialog)
        self.buttonBox.setOrientation(QtCore.Qt.Orientation.Horizontal)
        self.buttonBox.setStandardButtons(
            QtWidgets.QDialogButtonBox.StandardButton.Cancel | QtWidgets.QDialogButtonBox.StandardButton.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.buttonBox.accepted.connect(self.accept)
        self.buttonBox.rejected.connect(self.reject)
        self.gridLayout.addWidget(self.buttonBox, 1, 0, 1, 1)

        self.retranslateUi(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Настройки подключения"))
        self.label_12.setText(_translate("Dialog", "Хост:"))
        self.label_13.setText(_translate("Dialog", "Порт:"))
        self.label_14.setText(_translate("Dialog", "База данных:"))
        self.label_15.setText(_translate("Dialog", "Пользователь:"))
        self.label_16.setText(_translate("Dialog", "Пароль:"))

    def get_db_connection(self) -> DbConnection:
        """Возвращает DbConnection из данных диалога"""
        return DbConnection(
            host=self.host_edit.text(),
            port=int(self.port_edit.text()),
            database=self.database_edit.text(),
            username=self.username_edit.text(),
            password=self.password_edit.text()
        )