from qgis.core import QgsPointXY

from qgis_route_planner.repositories.road_graph_repository import RoadGraphRepository


class RoutingService:
    def __init__(self, graph_repo: RoadGraphRepository):
        self.__graph_repo = graph_repo
        self.__current_route = None

    def is_point_on_road_network(self, point: QgsPointXY) -> bool:
        """Проверяет, находится ли точка на дорожной сети"""
        return self.__graph_repo.is_point_on_road_network(point.x(), point.y())

    def find_nearest_node(self, point: QgsPointXY) -> int | None:
        """Находит ближайший узел графа к точке"""
        result = self.__graph_repo.find_nearest_node(point.x(), point.y())
        if result:
            return result[0]  # Возвращаем только node_id
        return None

    def snap_point_to_road(self, point: QgsPointXY) -> tuple[QgsPointXY, int] | None:
        """Привязывает точку к ближайшей дороге и возвращает точку и ID узла"""
        node_info = self.__graph_repo.find_nearest_node(point.x(), point.y())
        if node_info:
            node_id, distance = node_info
            # Получаем координаты узла из БД
            coords = self.__graph_repo.get_node_coordinates(node_id)
            if coords:
                return QgsPointXY(coords[0], coords[1]), node_id
        return None

    def calculate_route(self, start_node_id: int, end_node_id: int) -> list[dict]:
        """Вычисляет маршрут между двумя узлами"""
        try:
            route = self.__graph_repo.get_route(start_node_id, end_node_id)
            self.__current_route = route
            return route
        except Exception as e:
            print(f"Error calculating route: {e}")
            return None

    def get_route_info(self, route: list[dict]) -> dict:
        """Получает информацию о маршруте (длина, время)"""
        total_distance = sum(edge['cost'] for edge in route)
        total_time = total_distance / 50  # Предполагаем среднюю скорость 50 км/ч

        return {
            'distance_km': total_distance / 1000,
            'time_hours': total_time / 60,
            'time_minutes': total_time,
            'segments': len(route)
        }

    def clear_route(self):
        """Очищает текущий маршрут"""
        self.__current_route = None