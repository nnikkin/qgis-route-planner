class BaseRestriction:
    def __init__(self, points:list[float]):
        self._points = points

    @property
    def points(self):
        return self._points