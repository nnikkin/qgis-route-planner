from qgis_route_planner.repositories.db_connection import DbConnection


class RestrictionRepository:
    def __init__(self, db: DbConnection):
        self._db = db

    def get_all(self) -> list[dict]:
        return self._db.execute_query(
            "SELECT  FROM routing.restrictions"
        )

    def get_by_id(self, restr_id: int) -> dict | None:
        rows = self._db.execute_query(
            "SELECT * FROM routing.restrictions WHERE id = %s",
            [restr_id]
        )
        return rows[0] if rows else None

    def add_profile(self, restr: Any):
        self._db.execute_nquery(
            "INSERT INTO routing.restrictions () "
            "VALUES ()",
            []
        )

    def del_profile(self, restr_id: int):
        self._db.execute_nquery(
            "DELETE FROM routing.restrictions WHERE id = %s", [restr_id]
        )

    def upd_profile(self, restr_id: int, restr: Any):
        self._db.execute_nquery(
            "UPDATE routing.restrictions SET "
            "WHERE id = %s",
            [..., restr_id]
        )