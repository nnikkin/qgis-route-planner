from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QAction, QCursor
from qgis.PyQt.QtWidgets import QMenu, QMessageBox, QListWidgetItem
from qgis.gui import QgsMapToolPan, QgsMapToolZoom, QgsVertexMarker
from qgis.core import QgsPointXY, QgsGeometry, QgsWkbTypes

from qgis_route_planner.models.route.point_type import PointType
from qgis_route_planner.models.route.route_point import RoutePoint
from qgis_route_planner.services.map_service import MapService
from qgis_route_planner.services.routing_service import RoutingService
from qgis_route_planner.services.settings_service import SettingsService
from qgis_route_planner.views.main_view import PluginMainWindow
from qgis_route_planner.views.widgets.select_point_map_tool import SelectPointMapTool



class MapController:
    def __init__(self, view: PluginMainWindow, map_service: MapService, settings_service: SettingsService,
                 routing_service: RoutingService):
        self.__view = view
        self.__map_service = map_service
        self.__settings_service = settings_service
        self.__routing_service = routing_service

        self.__next_point_id = 1
        self.__points = []  # Список всех точек
        self.__context_menu_point = None  # Точка для контекстного меню
        self.__point_markers = {}  # Словарь {point_id: marker}
        self.__current_route = None
        self.__route_band = None

        self.__point_zoom_in = QgsMapToolZoom(self.__view.mapView, False)
        self.__point_zoom_out = QgsMapToolZoom(self.__view.mapView, True)
        self.__point_pan = QgsMapToolPan(self.__view.mapView)
        self.__point_select_tool = SelectPointMapTool(self.__view.mapView)

        self.connect_signals()

    def connect_signals(self):
        self.__view.mapView.zoom_in_btn.clicked.connect(self.zoom_in)
        self.__view.mapView.zoom_out_btn.clicked.connect(self.zoom_out)
        self.__view.mapView.pan_btn.clicked.connect(self.pan)
        self.__view.mapView.select_btn.clicked.connect(self.activate_selection)
        self.__point_select_tool.pointClicked.connect(self.on_map_point_selected)
        self.__view.mapView.customContextMenuRequested.connect(self.show_context_menu_for_point)
        self.__view.clear_list_button.clicked.connect(self.clear_all_points)

    def activate_selection(self):
        """Активирует режим выбора точки"""
        self.__view.mapView.setMapTool(self.__point_select_tool)

    def initialize_map(self, schema: str = "routing"):
        """Загружает слои из указанной схемы и настраивает карту"""
        try:
            layers = self.__map_service.load_all_spatial_layers(schema=schema)
            if layers:
                self.__view.mapView.set_layers(layers)
                self.__road_layer = next(
                    (l for l in layers if l.name() in {"graph_edges", f"{schema}.graph_edges"}),
                    None
                )
                print("Слои загружены.")
            else:
                print(f"No layers loaded from schema '{schema}'")
        except Exception as e:
            print(f"Failed to initialize map: {e}")

    def _determine_point_type(self) -> str:
        """
        Определяет тип новой точки на основе существующих
        """
        if not self.__points:
            return PointType.START
        elif len(self.__points) == 1:
            return PointType.END
        else:
            return PointType.WAYPOINT

    def _get_next_order(self, point_type: PointType) -> int:
        """
        Определяет порядковый номер для новой точки
        """
        if point_type == PointType.START:
            # Сдвигаем все точки на 1
            for point in self.__points:
                point.order += 1
            return 0
        elif point_type == PointType.END:
            return len(self.__points)
        else:  # WAYPOINT
            # Вставляем перед конечной точкой
            end_index = len(self.__points) - 1
            for i, point in enumerate(self.__points):
                if i >= end_index:
                    point.order += 1
            return end_index

    def on_map_point_selected(self, point: QgsPointXY):
        """Обработка выбора точки на карте"""
        # Проверяем, находится ли точка на дорожной сети
        if not self.__routing_service.is_point_on_road_network(point):
            QMessageBox.warning(
                self.__view,
                "Ошибка",
                "Точка должна находиться на дорожной сети!\n"
                "Пожалуйста, выберите точку на дороге."
            )
            return

        # Привязываем точку к ближайшему узлу дорожной сети
        snapped = self.__routing_service.snap_point_to_road(point)
        if snapped:
            point, node_id = snapped
            # Сохраняем node_id для использования при добавлении точки
            self._temp_node_id = node_id
        else:
            self._temp_node_id = None

        self.show_context_menu_for_point(point)

    def show_context_menu_for_point(self, point: QgsPointXY):
        """Показывает контекстное меню для выбора типа точки"""
        menu = QMenu(self.__view.mapView)

        # Сохраняем точку и node_id для использования в lambda
        current_point = point
        current_node_id = getattr(self, '_temp_node_id', None)

        # Добавляем действия для выбора типа точки
        set_start_action = QAction("Установить как начальную точку", menu)
        set_start_action.triggered.connect(
            lambda: self.add_point_with_node(current_point, PointType.START, current_node_id)
        )
        menu.addAction(set_start_action)

        set_end_action = QAction("Установить как конечную точку", menu)
        set_end_action.triggered.connect(
            lambda: self.add_point_with_node(current_point, PointType.END, current_node_id)
        )
        menu.addAction(set_end_action)

        set_waypoint_action = QAction("Установить как промежуточную точку", menu)
        set_waypoint_action.triggered.connect(
            lambda: self.add_point_with_node(current_point, PointType.WAYPOINT, current_node_id)
        )
        menu.addAction(set_waypoint_action)

        # Показываем меню в позиции курсора
        menu.exec_(QCursor.pos())

    def add_point(self, point: QgsPointXY, point_type: PointType):
        """Добавляет точку на карту и в список"""
        # Получаем ближайший узел
        node_id = self.__routing_service.find_nearest_node(point)

        if node_id is None:
            QMessageBox.warning(
                self.__view,
                "Ошибка",
                "Не удалось найти ближайший узел дорожной сети.\n"
                "Пожалуйста, выберите точку ближе к дороге."
            )
            return

        order = self._get_next_order(point_type)

        route_point = RoutePoint(
            id=self.__next_point_id,
            point=point,
            point_type=point_type,
            order=order,
            node_id=node_id  # Сохраняем ID узла для маршрутизации
        )
        self.__next_point_id += 1
        self.__points.append(route_point)

        # Сортируем точки по порядку
        self.__points.sort(key=lambda p: p.order)

        # Добавляем маркер на карту
        self._add_point_marker(route_point)

        # Обновляем список в UI
        self._update_points_list()

        # Если есть начальная и конечная точки, строим маршрут
        self._try_build_route()

    def add_point_with_node(self, point: QgsPointXY, point_type: PointType, node_id: int = None):
        """Добавляет точку с известным node_id"""
        if node_id is None:
            node_id = self.__routing_service.find_nearest_node(point)

        if node_id is None:
            QMessageBox.warning(
                self.__view,
                "Ошибка",
                "Не удалось найти ближайший узел дорожной сети.\n"
                "Пожалуйста, выберите точку ближе к дороге."
            )
            return

        order = self._get_next_order(point_type)

        route_point = RoutePoint(
            id=self.__next_point_id,
            point=point,
            point_type=point_type,
            order=order,
            node_id=node_id
        )
        self.__next_point_id += 1
        self.__points.append(route_point)

        # Сортируем точки по порядку
        self.__points.sort(key=lambda p: p.order)

        # Добавляем маркер на карту
        self._add_point_marker(route_point)

        # Обновляем список в UI
        self._update_points_list()

        # Если есть начальная и конечная точки, строим маршрут
        self._try_build_route()

    def _add_point_marker(self, point: RoutePoint):
        """Добавляет маркер точки на карту"""
        marker = QgsVertexMarker(self.__view.mapView)
        marker.setCenter(point.point)
        marker.setIconType(QgsVertexMarker.IconType.ICON_CROSS)

        # Разные цвета для разных типов точек
        if point.point_type == PointType.START:
            marker.setColor(Qt.green)
            marker.setPenWidth(3)
        elif point.point_type == PointType.END:
            marker.setColor(Qt.red)
            marker.setPenWidth(3)
        else:
            marker.setColor(Qt.blue)
            marker.setPenWidth(2)

        marker.setIconSize(10)
        marker.show()

        self.__point_markers[point.id] = marker

    def _update_points_list(self):
        """Обновляет список точек в UI"""
        self.__view.points_list_widget.clear()

        for point in self.__points:
            # Формируем текст в зависимости от типа
            if point.point_type == PointType.START:
                prefix = "СТАРТ"
            elif point.point_type == PointType.END:
                prefix = "ФИНИШ"
            else:
                prefix = f"ТОЧКА {point.order}"

            point_text = f"{prefix}: ({point.point.x():.6f}, {point.point.y():.6f})"
            item = QListWidgetItem(point_text)
            item.setData(Qt.UserRole, point.id)
            self.__view.points_list_widget.addItem(item)

        self.__view.clear_list_button.setEnabled(len(self.__points) > 0)

    def remove_point(self, point_id: int):
        """Удаляет точку"""
        point_to_remove = next((p for p in self.__points if p.id == point_id), None)
        if point_to_remove:
            self.__points.remove(point_to_remove)

            # Удаляем маркер с карты
            if point_id in self.__point_markers:
                marker = self.__point_markers[point_id]
                self.__view.mapView.scene().removeItem(marker)
                del self.__point_markers[point_id]

            # Перенумеровываем порядок оставшихся точек
            for i, point in enumerate(self.__points):
                point.order = i

            self._update_points_list()
            self._try_build_route()

    def clear_all_points(self):
        """Очищает все точки"""
        # Удаляем все маркеры
        for point_id in list(self.__point_markers.keys()):
            marker = self.__point_markers[point_id]
            self.__view.mapView.scene().removeItem(marker)
        self.__point_markers.clear()

        # Очищаем список точек
        self.__points.clear()
        self.__next_point_id = 1

        # Очищаем маршрут
        self._clear_route()

        # Обновляем UI
        self._update_points_list()

    def change_point_type(self, point_id: int, new_type: PointType):
        """Изменяет тип точки"""
        point = next((p for p in self.__points if p.id == point_id), None)
        if point:
            old_type = point.point_type
            point.point_type = new_type

            # Обновляем порядок
            if old_type == PointType.START and new_type != PointType.START:
                # Была стартовая - делаем первую точку стартовой
                if self.__points:
                    self.__points[0].point_type = PointType.START
            elif old_type == PointType.END and new_type != PointType.END:
                # Была конечная - делаем последнюю точку конечной
                if self.__points:
                    self.__points[-1].point_type = PointType.END

            # Обновляем маркер
            self._update_marker_color(point)

            self._update_points_list()
            self._try_build_route()

    def _update_marker_color(self, point: RoutePoint):
        """Обновляет цвет маркера при изменении типа"""
        if point.id in self.__point_markers:
            marker = self.__point_markers[point.id]
            if point.point_type == PointType.START:
                marker.setColor(Qt.green)
            elif point.point_type == PointType.END:
                marker.setColor(Qt.red)
            else:
                marker.setColor(Qt.blue)

    def _try_build_route(self):
        """Пытается построить маршрут если есть start и end"""
        start_point = next((p for p in self.__points if p.point_type == PointType.START), None)
        end_point = next((p for p in self.__points if p.point_type == PointType.END), None)

        if start_point and end_point:
            print(f"Start point: id={start_point.id}, node_id={start_point.node_id}")
            print(f"End point: id={end_point.id}, node_id={end_point.node_id}")

            if start_point.node_id and end_point.node_id:
                route = self.__routing_service.calculate_route(start_point.node_id, end_point.node_id)
                if route:
                    self._display_route(route)
                    self._show_route_info(route)
                else:
                    QMessageBox.warning(
                        self.__view,
                        "Ошибка",
                        "Не удалось построить маршрут между выбранными точками"
                    )
            else:
                QMessageBox.warning(
                    self.__view,
                    "Ошибка",
                    "Не удалось определить узлы дорожной сети для выбранных точек"
                )
        else:
            self._clear_route()

    def _display_route(self, route: list):
        """Отображает маршрут на карте"""
        from qgis.gui import QgsRubberBand

        # Очищаем предыдущий маршрут
        self._clear_route()

        if not route:
            return

        # Создаем линию маршрута
        self.__route_band = QgsRubberBand(self.__view.mapView, QgsWkbTypes.LineGeometry)
        self.__route_band.setColor(Qt.blue)
        self.__route_band.setWidth(3)

        # Собираем все точки маршрута
        all_points = []
        for edge in route:
            geom = QgsGeometry.fromWkt(edge['geom'])
            all_points.extend(geom.asPolyline())

        if all_points:
            route_geom = QgsGeometry.fromPolylineXY(all_points)
            self.__route_band.setToGeometry(route_geom, None)
            self.__current_route = route

            # Масштабируем к маршруту
            self.__view.mapView.setExtent(route_geom.boundingBox())
            self.__view.mapView.refresh()

    def _show_route_info(self, route: list):
        """Отображает информацию о маршруте"""
        info = self.__routing_service.get_route_info(route)

        # Формируем текст с инструкциями
        instructions = self._generate_instructions(route)

        text = f"""
        <style>
            .route-info {{ font-family: Arial; margin: 10px; }}
            .title {{ font-size: 16px; font-weight: bold; color: #2c3e50; }}
            .stat {{ margin: 5px 0; }}
            .label {{ font-weight: bold; color: #34495e; }}
            .value {{ color: #2980b9; }}
            .instruction {{ margin: 8px 0; padding: 5px; background-color: #ecf0f1; border-radius: 3px; }}
        </style>
        <div class="route-info">
            <div class="title">== ИНФОРМАЦИЯ О МАРШРУТЕ ==</div>
            <div class="stat"><span class="label">Общая длина:</span> <span class="value">{info['distance_km']:.2f} км</span></div>
            <div class="stat"><span class="label">Примерное время:</span> <span class="value">{info['time_minutes']:.0f} минут</span></div>
            <div class="stat"><span class="label">Количество сегментов:</span> <span class="value">{info['segments']}</span></div>
            <div class="title" style="margin-top: 15px;">== ИНСТРУКЦИИ ПО МАРШРУТУ ==</div>
            {instructions}
        </div>
        """

        self.__view.route_info_widget.setHtml(text)

    def _generate_instructions(self, route: list) -> str:
        """Генерирует текстовые инструкции по маршруту"""
        if not route:
            return "<div>Нет инструкций</div>"

        instructions = []
        total_distance = 0

        for i, edge in enumerate(route):
            total_distance += edge['cost']
            distance_km = total_distance / 1000

            if i == 0:
                action = "Старт"
            elif i == len(route) - 1:
                action = "Финиш"
            else:
                # Определяем действие на основе угла поворота
                action = "Продолжать движение"

            instructions.append(f"""
            <div class="instruction">
                <b>{i + 1}.</b> {action}<br>
                <span style="color: #7f8c8d; font-size: 11px;">
                    Пройдено: {distance_km:.2f} км
                </span>
            </div>
            """)

        return "".join(instructions)

    def _clear_route(self):
        """Очищает маршрут с карты"""
        if self.__route_band:
            self.__view.mapView.scene().removeItem(self.__route_band)
            self.__route_band = None
        self.__current_route = None
        self.__view.route_info_widget.clear()

    def _populate_context_menu(self, menu, event):
        """Заполняет контекстное меню"""
        # Находим точку под курсором
        point_under_cursor = self._find_point_at_position(event)

        if point_under_cursor:
            self.__context_menu_point = point_under_cursor

            if point_under_cursor.point_type != PointType.START:
                set_start_action = QAction("Установить как начальную", menu)
                set_start_action.triggered.connect(
                    lambda: self.add_point(point_under_cursor, PointType.START))
                menu.addAction(set_start_action)

            if point_under_cursor.point_type != PointType.END:
                set_end_action = QAction("Установить как конечную", menu)
                set_end_action.triggered.connect(
                    lambda: self.add_point(point_under_cursor, PointType.END))
                menu.addAction(set_end_action)

            if point_under_cursor.point_type != PointType.WAYPOINT:
                set_waypoint_action = QAction("Установить как промежуточную", menu)
                set_waypoint_action.triggered.connect(
                    lambda: self.add_point(point_under_cursor, PointType.WAYPOINT))
                menu.addAction(set_waypoint_action)

            menu.addSeparator()

            delete_action = QAction("Удалить точку", menu)
            delete_action.triggered.connect(lambda: self.remove_point(point_under_cursor.id))
            menu.addAction(delete_action)

    def _find_point_at_position(self, pos) -> RoutePoint:
        """Находит точку под курсором"""
        # Получаем координаты клика на холсте карты
        canvas_point = pos

        # Проверяем расстояние до каждого маркера
        for point in self.__points:
            marker = self.__point_markers.get(point.id)
            if marker:
                # Получаем экранные координаты маркера
                marker_point = self.__view.mapView.mapToGlobal(
                    self.__view.mapView.mapToCanvas(marker.center())
                )
                # Проверяем расстояние в пикселях
                if abs(marker_point.x() - canvas_point.x()) < 15 and \
                        abs(marker_point.y() - canvas_point.y()) < 15:
                    return point
        return None


    def zoom_in(self):
        self.__view.mapView.setMapTool(self.__point_zoom_in)

    def zoom_out(self):
        self.__view.mapView.setMapTool(self.__point_zoom_out)

    def pan(self):
        self.__view.mapView.setMapTool(self.__point_pan)
