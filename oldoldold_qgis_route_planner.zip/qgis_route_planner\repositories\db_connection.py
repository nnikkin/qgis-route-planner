from dataclasses import dataclass

import psycopg


class DbConnection:
    """Низкоуровневый класс для работы с БД"""

    def __init__(self, host: str, port: int, database: str, username: str, password: str):
        self.__host = host
        self.__port = port
        self.__database = database
        self.__username = username
        self.__password = password

    @property
    def host(self) -> str:
        return self.__host

    @property
    def port(self) -> int:
        return self.__port

    @property
    def database(self) -> str:
        return self.__database

    @property
    def username(self) -> str:
        return self.__username

    @property
    def password(self) -> str:
        return self.__password

    def _get_connection(self):
        """Создает новое соединение"""
        if not self.is_complete():
            raise ValueError("Connection parameters are not set")

        return psycopg.connect(
            host=self.__host,
            port=self.__port,
            dbname=self.__database,
            user=self.__username,
            password=self.__password,
        )

    def execute_query(self, query: str, params: list = None):
        """Выполнить запрос с возвратом строк (SELECT)"""
        with psycopg.connect(host=self.__host, port=self.__port,
                             dbname=self.__database, user=self.__username,
                             password=self.__password) as conn:
            with conn.cursor() as cursor:
                cursor.execute(query, params)
                return cursor.fetchall()

    def execute_nquery(self, query: str, params: list = None):
        """Выполнить запрос без возврата строк (INSERT/DELETE/UPDATE)"""
        with psycopg.connect(host=self.__host, port=self.__port,
                             dbname=self.__database, user=self.__username,
                             password=self.__password) as conn:
            with conn.cursor() as cursor:
                cursor.execute(query, params)

    def test_connection(self) -> bool:
        """Проверяет возможность подключения"""
        try:
            with self._get_connection():
                return True
        except Exception:
            return False

    def is_complete(self) -> bool:
        return all([self.__host, self.__port, self.__database, self.__username])