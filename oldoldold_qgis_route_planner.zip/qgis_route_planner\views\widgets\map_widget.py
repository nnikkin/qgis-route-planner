from qgis.PyQt.QtGui import QFont
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QVBoxLayout, QPushButton, QWidget

from qgis.core import (
    QgsVectorLayer,
    QgsRectangle
)

from qgis.gui import (
    QgsMapCanvas
)

class MapWidget(QgsMapCanvas):
    def __init__(self):
        super().__init__()
        self.__layers = []

        self.setObjectName("mapWidget")
        self.setCanvasColor(Qt.white)
        self.enableAntiAliasing(True)
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)

        # создание управления картой
        self.__map_controls = QWidget(self)
        self.__map_controls.setStyleSheet("background: rgba(255,255,255,180);")
        self.__btns_layout = QVBoxLayout(self.__map_controls)

        self.__btn_zoomin = QPushButton("+", self)
        self.__btn_zoomin.setFont(QFont("Arial", 14))
        self.__btn_zoomin.setToolTip("Увеличить масштаб")

        self.__btn_zoomout = QPushButton("-", self)
        self.__btn_zoomout.setFont(QFont("Arial", 14))
        self.__btn_zoomout.setToolTip("Уменьшить масштаб")

        self.__btn_pan = QPushButton("I", self)
        self.__btn_pan.setFont(QFont("Wingdings", 14))
        self.__btn_pan.setToolTip("Режим перемещения по карте")

        self.__btn_select = QPushButton("±", self)
        self.__btn_select.setFont(QFont("Wingdings", 14))
        self.__btn_select.setToolTip("Режим выбора точки")

        for btn in self.__btn_zoomin, self.__btn_pan, self.__btn_select, self.__btn_zoomout:
            btn.setFixedSize(30, 30)
            btn.setContentsMargins(0, 0, 0, 30)
            self.__btns_layout.addWidget(btn)

        self.__map_controls.adjustSize()

    '''
    def remove_item(self, item: QgsRubberBand | QgsVertexMarker):
        """
        Deletes an item (a QgsRubberBand or a QgsVertexMarker) from the map
        """
        if item:
            item.reset(QgsWkbTypes.LineGeometry)
            self.scene().removeItem(item)

    def hide_item(self, item: QgsRubberBand | QgsVertexMarker):
        """
        Hides an item (a QgsRubberBand or a QgsVertexMarker) on the map
        """
        self.scene().hide(item)

    def show_item(self, item: QgsRubberBand | QgsVertexMarker):
        """
        Shows a perviously hidden item (a QgsRubberBand or a QgsVertexMarker) on the map
        """
        self.scene().show(item)
    '''

    """Геттеры кнопок навигации по карте"""
    @property
    def zoom_in_btn(self):
        return self.__btn_zoomin

    @property
    def zoom_out_btn(self):
        return self.__btn_zoomout

    @property
    def pan_btn(self):
        return self.__btn_pan

    @property
    def select_btn(self):
        return self.__btn_select

    def set_layers(self, layers: list):
        """Устанавливает слои на карту (чистое отображение)"""
        self.__layers = layers
        self.setLayers(layers)

        for layer in self.__layers:
            self.setExtent(layer.extent())

        self.refresh()

    def add_layer(self, layer: QgsVectorLayer):
        """Добавляет слой (чистое отображение)"""
        current_layers = self.__layers
        current_layers.append(layer)
        self.set_layers(current_layers)