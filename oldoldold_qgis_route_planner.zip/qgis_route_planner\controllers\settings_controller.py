from qgis_route_planner.repositories.db_connection import DbConnection
from qgis_route_planner.services.settings_service import SettingsService
from qgis_route_planner.views.settings_view import SettingsWindow

from qgis.PyQt.QtWidgets import QDialog, QMessageBox
from qgis.PyQt.QtCore import pyqtSignal

class SettingsController:
    """Контроллер диалога настроек плагина"""

    # Сигнал, который будет отправляться при сохранении настроек
    settings_saved = pyqtSignal(DbConnection)

    def __init__(self, settings_service: SettingsService):
        self._settings_window_scaffold = None
        self._settings_window = None
        self._settings_service = settings_service

    def create_window(self, parent) -> SettingsWindow:
        if self._settings_window_scaffold is None:
            self._settings_window_scaffold = QDialog(parent)
            self._settings_window = SettingsWindow(parent)
            self._settings_window.setupUi(self._settings_window_scaffold)
            self._connect_signals()
            self._initialize()
        return self._settings_window_scaffold

    def _connect_signals(self):
        """Подключает сигналы"""
        self._settings_window.saveConButton.clicked.connect(self._save_db_settings)

    def set_current_tab(self, tab_index: int = 0):
        self._settings_window.tabWidget.setCurrentIndex(tab_index)

    def _initialize(self):
        self._load_db_settings()

    def _load_db_settings(self):
        try:
            s = self._settings_service.load_db_params()
            self._settings_window.hostnameEdit.setText(s.host)
            self._settings_window.portEdit.setText(str(s.port))
            self._settings_window.usernameEdit.setText(s.username)
            self._settings_window.passwordEdit.setText(s.password)
            if hasattr(self._settings_window, 'dbComboBox'):
                # Устанавливаем базу данных
                pass
            if hasattr(self._settings_window, 'schemaComboBox'):
                # Устанавливаем схемы
                pass

        except Exception as e:
            print(e)

    def _save_db_settings(self):
        host = self._settings_window.hostnameEdit.text()
        port = self._settings_window.portEdit.text()
        username = self._settings_window.usernameEdit.text()
        password = self._settings_window.passwordEdit.text()
        schema = self._settings_window.schemaComboBox.currentIndex()
        database = self._settings_window.dbComboBox.currentIndex()

        # Получаем имя базы данных (в зависимости от UI)
        if hasattr(self._settings_window, 'dbComboBox'):
            database = self._settings_window.dbComboBox.currentText()
        else:
            database = "osm"  # Значение по умолчанию

        if self._validate_db_settings(host, port, database, username, password):
            try:
                db_connection = DbConnection(
                    host=host,
                    port=int(port),
                    database=database,
                    username=username,
                    password=password
                )
                self._settings_service.save_db_params(db_connection)
                self.settings_saved.emit(db_connection)

                QMessageBox.information(
                    parent=self._settings_window_scaffold,
                    text="Настройки успешно сохранены!",
                    buttons=QMessageBox.Ok,
                )
            except Exception as e:
                print(e)
                QMessageBox.critical(
                    parent=self._settings_window_scaffold,
                    text=f"Ошибка сохранения: {str(e)}",
                    buttons=QMessageBox.Ok,
                )
        else:
            QMessageBox().warning(
                parent=self._settings_window_scaffold,
                text="Введены неверные значения. Попробуйте ещё раз.",
                buttons=QMessageBox.Ok,
            )
            print("User entered invalid DB settings!!")

    def _validate_db_settings(self, host: str, port: str, db_name: str, username: str, password: str) -> bool:
        try:
            port_int = int(port)
            return (len(host) > 0 and port_int > 0
                    and len(db_name) > 0 and len(username) > 0
                    and len(password) > 0)
        except ValueError:
            return False