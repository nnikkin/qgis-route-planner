from qgis_route_planner.controllers.map_controller import MapController
from qgis_route_planner.controllers.settings_controller import SettingsController
from qgis_route_planner.repositories.db_connection import DbConnection
from qgis_route_planner.repositories.layer_repository import LayerRepository
from qgis_route_planner.repositories.road_graph_repository import RoadGraphRepository
from qgis_route_planner.services.map_service import MapService
from qgis_route_planner.services.routing_service import RoutingService
from qgis_route_planner.services.settings_service import SettingsService
from qgis_route_planner.views.dbconn_view import InitDbSettingsDialog
from qgis_route_planner.views.main_view import PluginMainWindow

from qgis.core import QgsTask, QgsApplication
from qgis.PyQt.QtCore import QTimer

class MainController:
    def __init__(self, main_window: PluginMainWindow, settings_controller: SettingsController,
                 settings_service: SettingsService, routing_service: RoutingService, graph_repo: RoadGraphRepository):
        self._main_window = main_window
        self._settings_window = None

        self._graph_repo = graph_repo
        self._layer_repo = None
        self._db_connection = None

        self._routing_service = routing_service
        self._settings_service = settings_service
        self._map_service = None

        self._settings_controller = settings_controller
        self._map_controller = None

        self.connect_signals()

    def connect_signals(self):
        self._main_window.profiles_action.triggered.connect(lambda: self.open_settings_window(1))
        self._main_window.db_action.triggered.connect(lambda: self.open_settings_window())

    def open_settings_window(self, tab_index: int = 0):
        try:
            if self._settings_window is None:
                self._settings_window = self._settings_controller.create_window(self._main_window)
                self._settings_controller.settings_saved.connect(self._on_settings_saved)

            self._settings_controller.set_current_tab(tab_index)
            self._settings_window.exec_()
        except Exception as e:
            print(e)

    def _on_settings_saved(self, new_connection: DbConnection):
        """Обработчик сохранения новых настроек БД"""
        # Переподключаемся с новыми параметрами
        if self._test_connection(new_connection):
            self._init_repositories(new_connection)
            self.run_init_database()

    def _initialize_map(self, schema: str = "routing"):
        """Инициализирует карту для указанной схемы"""
        self._map_controller.initialize_map(schema=schema)

    def initialize(self):
        """Главный метод инициализации"""
        # Пытаемся загрузить параметры БД
        params = self._settings_service.load_db_params()
        print(f"Loaded params from settings: {params is not None}")

        # Если нет - пробуем взять из QGIS
        if not params:
            params = self._settings_service.try_get_from_qgis_connections()
            print(f"Loaded params from QGIS: {params is not None}")

        # Если всё равно нет или неполные - показываем диалог
        if not params or not params.is_complete():
            params = self._show_connection_dialog()
            if not params:
                print(f"No connection params provided!!")
                return False

        # Пробуем подключиться
        if not self._test_connection(params):
            print(f"Connection test failed!!")
            params = self._show_connection_dialog(error_text="Не удалось подключиться к БД")
            if not params:
                return False

        # Сохраняем параметры и инициализируем репозитории
        self._settings_service.save_db_params(params)
        self._init_repositories(params)

        self.run_init_database()

        return True

    def _show_connection_dialog(self, error_text: str = None):
        dialog = InitDbSettingsDialog(self._main_window, initial_params=self._db_connection, error_text=error_text)
        if dialog.exec_():
            return DbConnection(
                host=dialog.host_edit.text(),
                port=int(dialog.port_edit.text()),
                database=dialog.database_edit.text() if hasattr(dialog, 'database_edit') else '',
                username=dialog.username_edit.text(),
                password=dialog.password_edit.text()
            )
        return None

    def _test_connection(self, db_connection: DbConnection):
        """Проверка подключения к БД"""
        return db_connection.test_connection()

    def _init_repositories(self, db_connection: DbConnection):
        """Инициализирует репозитории с параметрами подключения"""
        self._db_connection = db_connection
        self._layer_repo = LayerRepository(self._db_connection)
        self._graph_repo = RoadGraphRepository(self._db_connection, self._layer_repo)

        self._routing_service = RoutingService(self._graph_repo)

        self._map_service = MapService(self._db_connection, self._layer_repo)

        self._map_controller = MapController(
            self._main_window,
            self._map_service,
            self._settings_service,
            self._routing_service
        )

    def run_init_database(self):
        self.task = QgsTask.fromFunction(
            'Инициализация БД',
            self._graph_repo.init_database,
            on_finished=self._handle_init_finished,
            result=True
        )

        self.task.taskCompleted.connect(lambda: print("Задача завершена"))
        self.task.taskTerminated.connect(lambda: print(f"Задача прервана с ошибкой! {self.task.status()}"))

        QgsApplication.taskManager().addTask(self.task)

    def _handle_init_finished(self, result):
        try:
            if result:
                self._load_initial_layers()
            else:
                print("returned False")
        except Exception as e:
            print(e)

    def _load_initial_layers(self):
        try:
            if not self._map_controller:
                print("MapController не инициализирован")
                return

            layer = self._map_service.load_layer_from_db(
                table_name="graph_edges",
                schema="routing",
                geom_col="geom",
                key_col="edge_id"
            )

            if layer.isValid():
                self._initialize_map(schema="routing")
            else:
                print("Ошибка: Слой невалиден. Проверьте параметры подключения.")
        except Exception as e:
            print(f"Ошибка загрузки слоя routing.graph_edges: {e}")