import psycopg
from qgis_route_planner.repositories.db_connection import DbConnection
from qgis_route_planner.repositories.layer_repository import LayerRepository

from qgis.core import QgsTask

class RoadGraphRepository:
    def __init__(self, db: DbConnection, layer_repository: LayerRepository):
        self.__db = db
        self.__layer_repository = layer_repository
        pass

    def create_topology(self, task) -> bool:
        """
            Creates a routing graph
        """

        count = self.__db.execute_query("SELECT COUNT(*) FROM routing.graph_edges;")
        if task.isCanceled(): return False
        if count and count[0][0] == 0:
            print("Нет данных в таблице graph_edges. Сначала загрузите данные!")
            return False

        # Заполнение source и target
        self.__db.execute_nquery("""
            UPDATE routing.graph_edges AS e
            SET source = v.node_id
            FROM routing.graph_nodes AS v
            WHERE ST_DWithin(ST_StartPoint(e.geom), v.geom, 0.000001);
         """)
        if task.isCanceled(): return False

        self.__db.execute_nquery("""
            UPDATE routing.graph_edges AS e
            SET target = v.node_id
            FROM routing.graph_nodes AS v
            WHERE ST_DWithin(ST_EndPoint(e.geom), v.geom, 0.000001);
        """)
        if task.isCanceled(): return False

        # Заполнение cost как длину в метрах
        self.__db.execute_nquery("""
            UPDATE routing.graph_edges
            SET
                cost = ST_Length(geom::geography),
                reverse_cost = ST_Length(geom::geography);
        """)
        if task.isCanceled(): return False

        # Для односторонних дорог устанавливаем reverse_cost = -1
        self.__db.execute_nquery("""
                UPDATE routing.graph_edges
                SET reverse_cost = -1
                WHERE is_oneway = TRUE;
            """)
        if task.isCanceled(): return False

        return True

    def init_database(self, task: QgsTask) -> bool:
        """
            Creates necessary tables
        """
        try:
            if task.isCanceled(): return False

            for cmd in [
                'CREATE SCHEMA IF NOT EXISTS routing;',
                'CREATE EXTENSION IF NOT EXISTS postgis;',
                'CREATE EXTENSION IF NOT EXISTS pgrouting;',
                'CREATE EXTENSION IF NOT EXISTS hstore;'
            ]:
                self.__db.execute_nquery(cmd)

            if task.isCanceled(): return False
            self.__db.execute_nquery("""
                CREATE TABLE IF NOT EXISTS routing.graph_nodes (
                    node_id BIGINT PRIMARY KEY,
                    in_edges BIGINT[],
                    out_edges BIGINT[],
                    x DOUBLE PRECISION,
                    y DOUBLE PRECISION,
                    geom GEOMETRY(Point, 4326)
                );
            """)

            if task.isCanceled(): return False
            self.__db.execute_nquery("""
                CREATE TABLE IF NOT EXISTS routing.graph_edges (
                    edge_id BIGINT PRIMARY KEY,
                    source BIGINT REFERENCES routing.graph_nodes(node_id),
                    target BIGINT REFERENCES routing.graph_nodes(node_id),
                    geom GEOMETRY(LineString, 4326),
                    cost DOUBLE PRECISION,
                    reverse_cost DOUBLE PRECISION,
                    road_class TEXT,
                    name TEXT,
                    is_oneway BOOLEAN,
                    max_speed_kmh DOUBLE PRECISION
                );
            """)

            if task.isCanceled(): return False
            self.__db.execute_nquery(f"""
            INSERT INTO routing.graph_edges (
                edge_id, geom, road_class, name, is_oneway, max_speed_kmh
            )
            SELECT 
                osm_id::bigint,
                ST_Transform(geom, 4326),
                highway, 
                name,
                CASE 
                    -- Приводим other_tags к типу hstore перед использованием оператора ->
                    WHEN (other_tags::hstore)->'oneway' IN ('yes', '1', 'true') THEN TRUE 
                    ELSE FALSE 
                END,
                COALESCE(
                    NULLIF(regexp_replace((other_tags::hstore)->'maxspeed', '[^0-9]', '', 'g'), '')::double precision, 
                    60
                )
            FROM public.lines
            WHERE highway IS NOT NULL
            ON CONFLICT (edge_id) DO NOTHING;
        """)

            if task.isCanceled(): return False
            count = self.__db.execute_query("SELECT COUNT(*) FROM routing.graph_nodes;")[0][0]
            if count == 0:
                self.__db.execute_nquery("""
                    INSERT INTO routing.graph_nodes (node_id, in_edges, out_edges, x, y, geom)
                    SELECT id, in_edges, out_edges, x, y, geom
                    FROM pgr_extractVertices(
                        'SELECT edge_id as id, geom FROM routing.graph_edges ORDER BY edge_id'
                    )
                    ON CONFLICT (node_id) DO NOTHING;
                """)

            if task.isCanceled(): return False
            self.__db.execute_nquery("""
                CREATE TABLE IF NOT EXISTS routing.restriction_types (
                    restriction_type_id SMALLINT PRIMARY KEY,
                    code TEXT,
                    name TEXT
                );
            """)

            if task.isCanceled(): return False
            self.__db.execute_nquery("""
                CREATE TABLE IF NOT EXISTS routing.restriction_info (
                    restriction_info_id BIGINT PRIMARY KEY,
                    valid_from_date DATE,
                    valid_from_time TIME,
                    valid_to_date DATE,
                    valid_to_time TIME,
                    comment TEXT
                );
            """)

            if task.isCanceled(): return False
            self.__db.execute_nquery("""
                CREATE TABLE IF NOT EXISTS routing.edge_restrictions (
                    restriction_id BIGINT PRIMARY KEY,
                    restriction_type_id SMALLINT REFERENCES routing.restriction_types(restriction_type_id),
                    restriction_info_id BIGINT REFERENCES routing.restriction_info(restriction_info_id),
                    edge_id BIGINT REFERENCES routing.graph_edges(edge_id),
                    value_num DOUBLE PRECISION,
                    value_text TEXT
                );
            """)

            if task.isCanceled(): return False
            self.__db.execute_nquery("""
                CREATE TABLE IF NOT EXISTS routing.node_restrictions (
                    restriction_id BIGINT PRIMARY KEY,
                    restriction_type_id SMALLINT REFERENCES routing.restriction_types(restriction_type_id),
                    restriction_info_id BIGINT REFERENCES routing.restriction_info(restriction_info_id),
                    node_id BIGINT REFERENCES routing.graph_nodes(node_id),
                    value_num DOUBLE PRECISION,
                    value_text TEXT
                );
            """)

            if task.isCanceled(): return False
            self.__db.execute_nquery("""
                CREATE TABLE IF NOT EXISTS routing.turn_restrictions (
                    restriction_id BIGINT PRIMARY KEY,
                    via_node_id BIGINT REFERENCES routing.graph_nodes(node_id),
                    to_edge_id BIGINT REFERENCES routing.graph_edges(edge_id),
                    restriction_info_id BIGINT REFERENCES routing.restriction_info(restriction_info_id)
                );
            """)

            if task.isCanceled(): return False
            # Создаём индексы для производительности
            self.__db.execute_nquery("""
                CREATE INDEX IF NOT EXISTS idx_graph_edges_geom 
                ON routing.graph_edges USING GIST (geom);
            """)

            if task.isCanceled(): return False
            self.__db.execute_nquery("""
                CREATE INDEX IF NOT EXISTS idx_graph_nodes_geom 
                ON routing.graph_nodes USING GIST (geom);
            """)

            self.create_topology(task)
            if task.isCanceled(): return False

            print("Инициализация завершена успешно")
            return True

        except Exception as e:
            print(f"КРИТИЧЕСКАЯ ОШИБКА В ПОТОКЕ: {e}")
            import traceback

            traceback.print_exc()  # Выведет полную ошибку в консоль QGIS
            return False

    def get_route(self, start_id: int, end_id: int) -> list[dict]:
        print(f"Поиск маршрута от {start_id} до {end_id}")

        # Проверяем существование узлов
        start_check = self.__db.execute_query(
            "SELECT node_id FROM routing.graph_nodes WHERE node_id = %s",
            [start_id]
        )
        end_check = self.__db.execute_query(
            "SELECT node_id FROM routing.graph_nodes WHERE node_id = %s",
            [end_id]
        )

        if not start_check:
            print(f"Стартовый узел {start_id} не найден в БД!")
            return []
        if not end_check:
            print(f"Конечный узел {end_id} не найден в БД!")
            return []

        res = self.__db.execute_query("""
            SELECT e.edge_id, ST_AsGeoJSON(e.geom) AS geom_json,
                   r.cost, r.agg_cost
            FROM pgr_dijkstra(
                'SELECT edge_id as id, source, target, cost, reverse_cost
                 FROM routing.graph_edges',
                %s, %s
            ) AS r
            JOIN routing.graph_edges AS e ON r.edge = e.edge_id
            ORDER BY r.seq
        """, [start_id, end_id])

        print(f"Найдено сегментов маршрута: {len(res)}")
        return res


    def find_nearest_node(self, x: float, y: float, max_distance_m: float = 50.0):
        """
        Находит ближайший узел графа к заданной точке
        Возвращает (node_id, distance) или None
        """
        result = self.__db.execute_query("""
            SELECT node_id, 
                   ST_Distance(
                       geom::geography, 
                       ST_SetSRID(ST_MakePoint(%s, %s), 4326)::geography
                   ) as distance
            FROM routing.graph_nodes
            WHERE ST_DWithin(
                geom::geography, 
                ST_SetSRID(ST_MakePoint(%s, %s), 4326)::geography, 
                %s
            )
            ORDER BY distance
            LIMIT 1
        """, [x, y, x, y, max_distance_m])

        print(f"max distance: {max_distance_m}")
        print(result[0] if result else None)
        return result[0] if result else None

    def is_point_on_road_network(self, x: float, y: float, max_distance_m: float = 50.0) -> bool:
        """Проверяет, находится ли точка на дорожной сети"""
        print(x, y)
        return self.find_nearest_node(x, y, max_distance_m) is not None

    def get_node_coordinates(self, node_id: int) -> tuple[float, float] | None:
        """
        Возвращает координаты узла (x, y) по его ID.
        """
        query = """
            SELECT x, y 
            FROM routing.graph_nodes 
            WHERE node_id = %s
        """
        result = self.__db.execute_query(query, [node_id])

        if result and len(result) > 0:
            # result[0] — это первая строка, result[0][0] — это x, result[0][1] — это y
            return float(result[0][0]), float(result[0][1])

        return None