from qgis.PyQt.QtCore import QSettings

from qgis_route_planner.repositories.db_connection import DbConnection


class SettingsService:
    """Сервис для работы с настройками плагина"""

    _SETTINGS_FILE = 'qgis_route_planner.ini'
    _GROUP_DB = 'database'

    def __init__(self):
        self._settings = QSettings(self._SETTINGS_FILE, QSettings.IniFormat)

    def load_db_params(self) -> DbConnection | None:
        """Загружает параметры БД из настроек"""
        self._settings.beginGroup(self._GROUP_DB)

        host = self._settings.value('host', 'localhost')
        port = self._settings.value('port', '5432')
        database = self._settings.value('database', '')
        username = self._settings.value('username', '')
        password = self._settings.value('password', '')

        self._settings.endGroup()

        # Создаем DbConnection
        db = DbConnection(host, int(port), database, username, password)
        return db if db.is_complete() else None

    def save_db_params(self, db: DbConnection):
        """Сохраняет параметры БД в настройки"""
        self._settings.beginGroup(self._GROUP_DB)
        self._settings.setValue('host', db.host)
        self._settings.setValue('port', db.port)
        self._settings.setValue('database', db.database)
        self._settings.setValue('username', db.username)
        self._settings.setValue('password', db.password)
        self._settings.endGroup()
        self._settings.sync()

    def try_get_from_qgis_connections(self, conn_name: str = 'postgres') -> DbConnection | None:
        """Пытается получить параметры из сохраненных подключений QGIS"""
        s = QSettings("QGIS")
        s.beginGroup("PostgreSQL/connections")

        host = s.value(f'{conn_name}/host')
        if not host:
            s.endGroup()
            return None

        params = DbConnection(
            host=host,
            port=s.value(f'{conn_name}/port', '5432'),
            database=s.value(f'{conn_name}/database', ''),
            username=s.value(f'{conn_name}/username', ''),
            password=s.value(f'{conn_name}/password', '')
        )
        s.endGroup()

        return params if params.is_complete() else None